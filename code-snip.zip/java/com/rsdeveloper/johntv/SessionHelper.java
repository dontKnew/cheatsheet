package com.rsdeveloper.johntv;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionHelper {

    private static final String PREFS_NAME = "videomeeting";
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public SessionHelper(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }
    public void saveString(String key, String value) {
        editor.putString(key, value);
        editor.apply();
    }
    public String getString(String key, String defaultValue) {
        return sharedPreferences.getString(key, defaultValue);
    }
    public void saveInt(String key, int value) {
        editor.putInt(key, value);
        editor.apply();
    }
    public int getInt(String key, int defaultValue) {
        return sharedPreferences.getInt(key, defaultValue);
    }
    public void saveBoolean(String key, boolean value) {
        editor.putBoolean(key, value);
        editor.apply();
    }
    public boolean getBoolean(String key, boolean defaultValue) {
        return sharedPreferences.getBoolean(key, defaultValue);
    }
    public void clear() {
        editor.clear();
        editor.apply();
    }
}

