package com.rsdeveloper.johntv.initsdk;

public interface AuthConstants {

	// TODO Change it to your web domain
	public final static String WEB_DOMAIN = "zoom.us";

	/**
	 * We recommend that, you can generate jwttoken on your own server instead of hardcore in the code.
	 * We hardcore it here, just to run the demo.
	 *
	 * You can generate a jwttoken on the https://jwt.io/
	 * with this payload:
	 * {
	 *
	 *     "appKey": "string", // app key
	 *     "iat": long, // access token issue timestamp
	 *     "exp": long, // access token expire time
	 *     "tokenExp": long // token expire time
	 * }
	 */
	public final static String SDK_JWTTOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzZGtLZXkiOiJIZlNMcTR4TVRfZWtfcEdSVmMxR3ciLCJhcHBLZXkiOiJIZlNMcTR4TVRfZWtfcEdSVmMxR3ciLCJpYXQiOjE3NDE5MjY5NDksImV4cCI6MTc0MjAxMzM0OSwidG9rZW5FeHAiOjE3NDIwMTMzNDksInJvbGUiOjB9.GMoWI7Sf0XMcLrispRDLws1-kpCdnq2dh9ln358fUas";

}
