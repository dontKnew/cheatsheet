package com.rsdeveloper.johntv.initsdk;

import us.zoom.sdk.ZoomSDKInitializeListener;

public interface InitAuthSDKCallback extends ZoomSDKInitializeListener {
}
