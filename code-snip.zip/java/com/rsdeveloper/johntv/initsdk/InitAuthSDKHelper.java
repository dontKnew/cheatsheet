package com.rsdeveloper.johntv.initsdk;

import android.content.Context;
import android.util.Log;

import com.rsdeveloper.johntv.Helper;
import com.rsdeveloper.johntv.NetworkHelper;

import org.json.JSONException;
import org.json.JSONObject;

import us.zoom.sdk.ZoomSDK;
import us.zoom.sdk.ZoomSDKInitParams;
import us.zoom.sdk.ZoomSDKInitializeListener;
import us.zoom.sdk.ZoomSDKRawDataMemoryMode;

/**
 * Init and auth zoom sdk first before using SDK interfaces
 */
public class InitAuthSDKHelper implements ZoomSDKInitializeListener {

    private final static String TAG = "InitAuthSDKHelper";

    private static InitAuthSDKHelper mInitAuthSDKHelper;

    private ZoomSDK mZoomSDK;

    private InitAuthSDKCallback mInitAuthSDKCallback;

    private InitAuthSDKHelper() {
        mZoomSDK = ZoomSDK.getInstance();
    }

    public synchronized static InitAuthSDKHelper getInstance() {
        mInitAuthSDKHelper = new InitAuthSDKHelper();
        return mInitAuthSDKHelper;
    }

    /**
     * init sdk method
     */
    public void initSDK(Context context, InitAuthSDKCallback callback) {
        if (!mZoomSDK.isInitialized()) {

            NetworkHelper network = new NetworkHelper();
            try {
                network.makeGetRequest(Helper.API_URL + "/meeting/sdk-token",new NetworkHelper.GetRequestCallback() {
                    @Override
                    public void onSuccess(String result) {
                        JSONObject response;
                        try {
                            response = new JSONObject(result);
                            if(response.getBoolean("success")){
                                mInitAuthSDKCallback = callback;
                                ZoomSDKInitParams initParams = new ZoomSDKInitParams();
                                initParams.jwtToken = response.getString("data");
                                initParams.enableLog = true;
                                initParams.enableGenerateDump =true;
                                initParams.logSize = 5;
                                initParams.domain=AuthConstants.WEB_DOMAIN;
                                initParams.videoRawDataMemoryMode = ZoomSDKRawDataMemoryMode.ZoomSDKRawDataMemoryModeStack;
                                mZoomSDK.initialize(context, (ZoomSDKInitializeListener) context, initParams);
                            }else{
                                Helper.alertBox(context, "Token Fetch Failed-135", response.getString("message"));
                            }
                        } catch (JSONException e) {
                            Helper.alertBox(context,  "Token Fetch Failed-139", e.toString());
                        }
                    }
                    @Override
                    public void onFailure(String error) {
                        Helper.alertBox(context, "Token Fetch Failed-146", error);
                    }
                });
            }catch (Exception e){
                Helper.alertBox(context, "Token Fetch Failed - 151", "Error : "+ e.toString());
            }
        }
    }

    /**
     * init sdk callback
     *
     * @param errorCode         defined in {@link us.zoom.sdk.ZoomError}
     * @param internalErrorCode Zoom internal error code
     */
    @Override
    public void onZoomSDKInitializeResult(int errorCode, int internalErrorCode) {
        Log.i(TAG, "onZoomSDKInitializeResult, errorCode=" + errorCode + ", internalErrorCode=" + internalErrorCode);

        if (mInitAuthSDKCallback != null) {
            mInitAuthSDKCallback.onZoomSDKInitializeResult(errorCode, internalErrorCode);
        }
    }

    @Override
    public void onZoomAuthIdentityExpired() {
        Log.e(TAG,"onZoomAuthIdentityExpired in init");
    }

    public void reset(){
        mInitAuthSDKCallback = null;
    }
}
