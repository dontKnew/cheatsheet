package com.rsdeveloper.johntv.models;

import java.io.Serializable;

public class MeetingModel implements Serializable {

    private String meeting_title, meeting_id;
    private String created_at;

    // Constructor
    public MeetingModel(String meeting_id, String meeting_title, String created_at) {
        this.meeting_id = meeting_id;
        this.meeting_title = meeting_title;
        this.created_at = created_at;
    }

    // Getters
    public String getMeetingId() {
        return meeting_id;
    }

    public String getMeetingTitle() {
        return meeting_title;
    }

    public String getCreatedAt() {
        return created_at;
    }

    // Setters
    public void setMeetingId(String meeting_id) {
        this.meeting_id = meeting_id;
    }

    public void setMeetingTitle(String meeting_title) {
        this.meeting_title = meeting_title;
    }

    public void setCreatedAt(String created_at) {
        this.created_at = created_at;
    }

    // toString method (Optional)
    @Override
    public String toString() {
        return "MeetingModel{" +
                "meeting_id='" + meeting_id + '\'' +
                ", meeting_title='" + meeting_title + '\'' +
                ", created_at='" + created_at + '\'' +
                '}';
    }
}
