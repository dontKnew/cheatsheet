package com.rsdeveloper.johntv.inmeetingfunction.zoommeetingui;

import us.zoom.sdk.NewMeetingActivity;

public class CustomNewZoomUIActivity extends NewMeetingActivity {
}
