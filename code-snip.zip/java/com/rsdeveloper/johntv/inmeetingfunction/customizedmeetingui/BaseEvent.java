package com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui;

public interface BaseEvent {
}
