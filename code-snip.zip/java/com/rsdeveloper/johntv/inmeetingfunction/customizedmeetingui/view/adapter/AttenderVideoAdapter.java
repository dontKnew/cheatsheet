package com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.view.adapter;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;


import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import us.zoom.sdk.InMeetingService;
import us.zoom.sdk.InMeetingUserInfo;
import us.zoom.sdk.MobileRTCVideoUnitAspectMode;
import us.zoom.sdk.MobileRTCVideoUnitRenderInfo;
import us.zoom.sdk.MobileRTCVideoView;
import us.zoom.sdk.SDKEmojiReactionType;
import us.zoom.sdk.ZoomSDK;

import com.rsdeveloper.johntv.Helper;
import com.rsdeveloper.johntv.R;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.emoji.EmojiReactionHelper;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.view.VideoListLayout;

public class AttenderVideoAdapter extends RecyclerView.Adapter<AttenderVideoAdapter.ViewHold> {
    public static final int REACTION_DURATION = 5000;
    public VideoListLayout videolist2;

    public interface ItemClickListener {
        void onItemClick(View view, int position, long userId);
    }

    List<Long> userList = new ArrayList<>();

    private Map<Long, EmojiParams> emojiUsers = new HashMap<>();

    Context context;


    private int itemSize = 200;

    private ItemClickListener listener;

    int selected = -1;


    View selectedView;

    private Handler handler = new Handler();

    public static class EmojiParams {
        public long userId;
        public SDKEmojiReactionType reactionType;
        public Runnable runnable;

        public EmojiParams(long userId, SDKEmojiReactionType reactionType) {
            this.userId = userId;
            this.reactionType = reactionType;
        }
    }

    public AttenderVideoAdapter(Context context, int viewWidth, ItemClickListener listener) {
        this.context = context;
        this.listener = listener;
        if (viewWidth > 0) {
            itemSize = (viewWidth - 40) / 4;
            Log.d(Helper.TAG, "Need to small the size +" + itemSize);
        }
    }

    public void updateSize(int size) {
        itemSize = size;
        notifyDataSetChanged();
    }

    public int getHalfScreenSize(){
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        int screenWidth = displayMetrics.widthPixels;
        return screenWidth / 2;
    }

    public int getHalfScreenSize2(){
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        int screenWidth = displayMetrics.heightPixels;
        return screenWidth / 2;
    }


    @Override
    public ViewHold onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_attend, parent, false);
        RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) view.getLayoutParams();
        params.width = getHalfScreenSize();
        params.height = getHalfScreenSize2();
        view.setLayoutParams(params);
        view.setOnClickListener(onClickListener);
        videolist2  = new VideoListLayout(context);
        return new ViewHold(view);
    }

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        private static final long DOUBLE_CLICK_TIME_DELTA = 300; // milliseconds
        private long lastClickTime = 0;
        private long lastClickedUserId = -1;

        @Override
        public void onClick(View view) {
            Long userId = (Long) view.getTag();
            long clickTime = System.currentTimeMillis();
            if (userId == null) return;
            if (userId.equals(lastClickedUserId) && (clickTime - lastClickTime) < DOUBLE_CLICK_TIME_DELTA) {
                videolist2.toggleVideoList();
                if (listener != null) {
                    int position = userList.indexOf(userId);
                    if (position >= userList.size() || position == -1) {
                        return;
                    }
                    listener.onItemClick(view, position, userId);
                    if (selectedView != null) {
//                         remove old selected...
                        selectedView.setBackgroundResource(R.drawable.video_item_bg);
                    }
                    view.setBackgroundResource(R.drawable.video_active_item_bg);
                    selectedView = view;
                    selected = position;
                }
                lastClickTime = 0;
            } else {
                lastClickTime = clickTime;
                lastClickedUserId = userId;
                Toast.makeText(context, "Tap twice to pin the video", Toast.LENGTH_SHORT).show();
            }
        }
    };

    public void clearVideo(){
        this.userList.clear();
    }

    public void setUserList(List<Long> userList) {
        this.userList.clear();
        if (null != userList) {
            List<Long> retUserList = new ArrayList<>();
            for (Long userId : userList) {
                if (!isWebinarAttendee(userId)) {
                    retUserList.add(userId);
                }
            }

            if (!retUserList.isEmpty()) {
                this.userList.addAll(retUserList);
            }
        }
    }
    public void addOneUser(Long userId) {
        long myUserId = ZoomSDK.getInstance().getInMeetingService().getMyUserID();
        if (userId == myUserId) {
            Log.d(Helper.TAG, "Add2 User Id" + userId);
            return;
        }
        if (!userList.contains(userId) && !isWebinarAttendee(userId) ) {
            userList.add(userId);
            notifyItemInserted(userList.size());
        }
    }
    public void removeOneUser(Long userId) {
        if (userList.contains(userId)) {
            int index = userList.indexOf(userId);
            userList.remove(index);
            if (index == selected) {
                selected = 0;
                notifyItemChanged(selected);
            }
            notifyItemRemoved(index);
        }
    }

    @Override
    public void onBindViewHolder(ViewHold holder, int position) {
        Long userId = userList.get(position);
        holder.videoView.getVideoViewManager().removeAllAttendeeVideoUnit();
        holder.videoView.getVideoViewManager().addAttendeeVideoUnit(userId, holder.renderInfo);
        holder.root.setTag(userId);
        holder.videoView.setTag(position);
        EmojiParams emojiParams = emojiUsers.get(userId);
        if (emojiParams != null) {
            int drawableId = EmojiReactionHelper.getEmojiReactionDrawableId(emojiParams.reactionType);
            if(drawableId == 0) {
                holder.ivEmoji.setVisibility(View.GONE);
                return;
            }
            holder.ivEmoji.setVisibility(View.VISIBLE);
            holder.ivEmoji.setImageDrawable(context.getResources().getDrawable(drawableId, null));
        } else {
            holder.ivEmoji.setVisibility(View.GONE);
        }

        if (position == selected) {
//            if (selectedView != null) {
////                old selected view
//                selectedView.setBackgroundResource(R.drawable.video_item_bg);
//            }
            holder.root.setBackgroundResource(R.drawable.video_active_item_bg);
            selectedView = holder.root;
        } else {
            if (holder.root != null) {
                holder.root.setBackgroundResource(0);
                holder.root.setBackgroundResource(R.drawable.video_item_bg);
            }
        }

    }

    public void addUserList(List<Long> list) {
        for (Long userId : list) {
            if (!userList.contains(userId) && !isWebinarAttendee(userId)) {
                userList.add(userId);
                notifyItemInserted(userList.size());
            }
        }
    }

    public void setEmojiUser(EmojiParams emojiParams) {
        EmojiParams existedEmojiParams = emojiUsers.put(emojiParams.userId, emojiParams);
        if (existedEmojiParams != null && existedEmojiParams.runnable != null) {
            handler.removeCallbacks(existedEmojiParams.runnable);
        }
        int index = userList.indexOf(emojiParams.userId);
        notifyItemChanged(index);

        emojiParams.runnable = () -> {
            emojiUsers.remove(emojiParams.userId);
            int pos = userList.indexOf(emojiParams.userId);
            notifyItemChanged(pos);
        };

        handler.postDelayed(emojiParams.runnable, REACTION_DURATION);
    }

    public long getSelectedUserId() {
        if (selected >= 0 && selected < userList.size()) {
            return userList.get(selected);
        }
        return -1;
    }

    public void removeUserList(List<Long> list) {
        if (null == list) {
            return;
        }
        for (Long userId : list) {
            if (userList.indexOf(userId) >= 0) {
                int index = userList.indexOf(userId);
                userList.remove(index);
                if (index == selected) {
                    selected = 0;
                    notifyItemChanged(selected);
                }
                notifyItemRemoved(index);
            }
        }
    }

    @Override
    public int getItemCount() {
        return null == userList ? 0 : userList.size();
    }
    
    public void clear() {
        handler.removeCallbacksAndMessages(null);
    }

    public boolean isWebinarAttendee(long userId) {
        InMeetingService inMeetingService = ZoomSDK.getInstance().getInMeetingService();
        if (inMeetingService == null) {
            return false;
        }
        if (!inMeetingService.isWebinarMeeting()) {
            return false;
        }

        InMeetingUserInfo userInfo = inMeetingService.getUserInfoById(userId);
        return userInfo != null && userInfo.getInMeetingUserRole() == InMeetingUserInfo.InMeetingUserRole.USERROLE_ATTENDEE;
    }

    class ViewHold extends RecyclerView.ViewHolder {

        View root;
        MobileRTCVideoView videoView;
        MobileRTCVideoUnitRenderInfo renderInfo;
        ImageView ivEmoji;

        ViewHold(View view) {
            super(view);
            root = view;
            videoView = view.findViewById(R.id.item_videoView);
            ivEmoji = view.findViewById(R.id.iv_emoji);
            videoView.setZOrderMediaOverlay(true);
            renderInfo = new MobileRTCVideoUnitRenderInfo(0, 0, 400, 300);
            renderInfo.aspect_mode = MobileRTCVideoUnitAspectMode.VIDEO_ASPECT_FULL_FILLED;
            renderInfo.is_username_visible = Helper.SHOW_USERNAME_FROM_VIDEO_LIST;
            renderInfo.enableGalleryMode= false; // false mean, its sdk set high resulotion if gallery mode false,
        }

    }
}
