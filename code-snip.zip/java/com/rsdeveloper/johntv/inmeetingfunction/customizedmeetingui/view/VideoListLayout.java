package com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.view;

import android.app.Service;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rsdeveloper.johntv.Helper;
import com.rsdeveloper.johntv.R;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.view.adapter.AttenderVideoAdapter;


public class VideoListLayout extends LinearLayout implements View.OnClickListener {

    View indicator;

    RecyclerView videoList;
    private int currentPinUser = 0;

    public VideoListLayout(Context context) {
        super(context);
        init();
    }

    public VideoListLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public VideoListLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        updateArrow();
        updateOrientation(getResources().getConfiguration().orientation);
    }

    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.layout_video_list_indicator,this,true);
        indicator = findViewById(R.id.videoList_indicator);
        videoList = findViewById(R.id.videoList);
        indicator.setOnClickListener(this);
        //videoList.addOnScrollListener(onScrollListener);
        updateArrow();
        updateOrientation(getResources().getConfiguration().orientation);
    }

    @Override
    public void onClick(View v) {
        if (v == indicator) {
            toggleVideoList();
        }
    }

    public void toggleVideoList() {
        if (indexOfChild(videoList) < 0) {
            Log.d(Helper.TAG, "Video List has been addView");
            addView(videoList);
        } else {
            Log.d(Helper.TAG, "Video List has been removeView");
            removeView(videoList);
        }
        updateArrow();
    }

    @Override
    public void setVisibility(int visibility) {
        super.setVisibility(visibility);
        if (visibility == VISIBLE) {
            if (indexOfChild(videoList) < 0) {
                addView(videoList);
            }
            updateArrow();
        } else {
            removeView(videoList);
        }
    }

    @Override
    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        int orientation = newConfig.orientation;
        updateArrow();
        updateOrientation(orientation);
    }

    private void updateOrientation(int orientation) {
        if(null==getLayoutParams()){
            return;
        }

        int numberOfColumns = 2;
        GridLayoutManager layoutManager = new GridLayoutManager(
                getContext(),
                numberOfColumns,
                GridLayoutManager.VERTICAL,
                false
        );
        videoList.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        videoList.setLayoutManager(layoutManager);
        videoList.setBackgroundColor(Color.parseColor("#000000"));
    }

  /*  RecyclerView.OnScrollListener onScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                recyclerView.postDelayed(() -> {
                    RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                    if (!(layoutManager instanceof GridLayoutManager)) return;

                    GridLayoutManager gridLayoutManager = (GridLayoutManager) layoutManager;
                    int first = gridLayoutManager.findFirstVisibleItemPosition();
                    View firstView = gridLayoutManager.findViewByPosition(first);
                    if (firstView == null) return;

                    int top = firstView.getTop();
                    int height = firstView.getMeasuredHeight();
                    int threshold = 5;

                    if (Math.abs(top)   <= threshold) {
                        return;
                    }
                    Log.d(Helper.TAG, " Top " + top);
                    if (top < 0) {
                        if (-top >= height / 2) {
                            recyclerView.smoothScrollBy(0, height + top);
                        } else {
                            recyclerView.smoothScrollBy(0, top);
                        }
                    } else if (top > 0) {
                        recyclerView.smoothScrollBy(0, top);
                    }
                }, 50);
            }

        }
    };
*/


    void updateArrow() {
        boolean visible = indexOfChild(videoList) > 0;
        if (visible) {
            indicator.setRotation(0);
        } else {
            indicator.setRotation(180);
        }
        /*if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (visible) {
                indicator.setRotation(0);
            } else {
                indicator.setRotation(180);
            }
        } else {
            if (visible) {
                indicator.setRotation(270);
            } else {
                indicator.setRotation(90);
            }
        }

        */
    }

}
