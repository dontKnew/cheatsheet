package com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.rawdata;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;

import com.rsdeveloper.johntv.Helper;

import java.nio.ByteBuffer;

import us.zoom.rawdatarender.RawDataBufferType;
import us.zoom.rawdatarender.ZoomTextureViewRender;
import us.zoom.sdk.IZoomSDKVideoRawDataDelegate;
import us.zoom.sdk.MobileRTCRawDataError;
import us.zoom.sdk.ZoomSDKRawDataType;
import us.zoom.sdk.ZoomSDKRenderer;
import us.zoom.sdk.ZoomSDKVideoRawData;
import us.zoom.sdk.ZoomSDKVideoResolution;

//note  use ZoomSurfaceViewRender for performance
//use ZoomTextureViewRender for  ui animation
public class RawDataRender extends ZoomTextureViewRender {

    private static final String TAG = "RawDataRenderer";

    private static HandlerThread handlerThread;

    private static Handler handler;

    private long mSubscribeId = -1;

    private ZoomSDKRawDataType mRawDataType;

    private boolean isSubscribeSuccess = false;

    private ZoomSDKRenderer rawDataHelper;

    private long cacheShareSourceId;

    private ZoomSDKRawDataType cacheRawDataType;

    private boolean removeBackground = false;

    public RawDataRender(Context context) {
        super(context);
        init();
    }

    public RawDataRender(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setBufferType(RawDataBufferType.BYTE_ARRAY);
        initRender();
        startRender();
        rawDataHelper = new ZoomSDKRenderer(videoRendererSink);
        rawDataHelper.setRawDataResolution(ZoomSDKVideoResolution.VideoResolution_360P);

        if (null == handlerThread) {
            handlerThread = new HandlerThread("RawDataCanvas");
            handlerThread.start();
            handler = new Handler(handlerThread.getLooper());
        }
    }

    public void setRawDataResolution(ZoomSDKVideoResolution resolution) {
        rawDataHelper.setRawDataResolution(resolution);
    }

    public ZoomSDKVideoResolution getResolution() {
        return rawDataHelper.getResolution();
    }

    /**
     * recycle view : move out then move in sometime cache hit  without call onBindViewHolder
     */
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        // onDetachedFromWindow  unSubscribe video and stop render get better performance
        startRender();
        if (null != cacheRawDataType && cacheShareSourceId >= 0) {
            subscribe(cacheShareSourceId, cacheRawDataType);
        }
        cacheRawDataType = null;
        cacheShareSourceId = -1;
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        // onDetachedFromWindow  unSubscribe video get better performance. eg recycleView
        stopRender();
        if (null != mRawDataType && mSubscribeId >= 0) {
            cacheShareSourceId = mSubscribeId;
            cacheRawDataType = mRawDataType;
        }
        unSubscribe();
    }

    public void onVideoStatusChange(boolean isOn) {
        if (!isOn) {
            clearImage(true);
        }
    }

    private ByteBuffer removeBackground(ByteBuffer yBuffer, ByteBuffer aBuffer) {
        if (aBuffer == null) {
            return yBuffer;
        }
        ByteBuffer newYBuffer = ByteBuffer.allocateDirect(yBuffer.capacity());
        int size = yBuffer.capacity();
        byte[] buffer = new byte[size];
        for (int i = 0; i < size; i++) {
            int val = aBuffer.get(i);
            if (val == 0) {
                buffer[i] = 0;
            } else {
                buffer[i] = yBuffer.get(i);
            }
        }
        newYBuffer.put(buffer);
        newYBuffer.rewind();
        return newYBuffer;
    }

    IZoomSDKVideoRawDataDelegate videoRendererSink = new IZoomSDKVideoRawDataDelegate() {

        @Override
        public void onUserRawDataStatusChanged(UserRawDataStatus status) {
            if (status == UserRawDataStatus.RawData_Off) {
                clearImage(0.0F, 0.0F, 0.0F, 1.0F);
            }
        }

        @Override
        public void onVideoRawDataFrame(final ZoomSDKVideoRawData zoomSDKRawData) {
            boolean isMainThread = Thread.currentThread() == Looper.getMainLooper().getThread();
            if (isMainThread && zoomSDKRawData.canAddRef()) {
                zoomSDKRawData.addRef();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        ByteBuffer yBuffer = zoomSDKRawData.getyBuffer();
                        if (removeBackground) {
                            yBuffer = removeBackground(zoomSDKRawData.getyBuffer(), zoomSDKRawData.getAlphaBuffer());
                        }
                        drawI420YUV(yBuffer, zoomSDKRawData.getuBuffer(), zoomSDKRawData.getvBuffer(),
                                zoomSDKRawData.getStreamWidth(), zoomSDKRawData.getStreamHeight(), zoomSDKRawData.getRotation(), 30);
                        zoomSDKRawData.releaseRef();
                    }
                });
            } else {
                ByteBuffer yBuffer = zoomSDKRawData.getyBuffer();
                if (removeBackground) {
                    yBuffer = removeBackground(zoomSDKRawData.getyBuffer(), zoomSDKRawData.getAlphaBuffer());
                }
                drawI420YUV(yBuffer, zoomSDKRawData.getuBuffer(), zoomSDKRawData.getvBuffer(),
                        zoomSDKRawData.getStreamWidth(), zoomSDKRawData.getStreamHeight(), zoomSDKRawData.getRotation(), 30);
            }

        }
    };

    public MobileRTCRawDataError subscribe(long subscribeId, ZoomSDKRawDataType type) {

        MobileRTCRawDataError ret = rawDataHelper.subscribe(subscribeId, type);

        mSubscribeId = subscribeId;
        mRawDataType = type;

        if (ret == MobileRTCRawDataError.MobileRTCRawData_Success) {
            isSubscribeSuccess = true;
        } else {
            isSubscribeSuccess = false;
        }
        cacheRawDataType = null;
        cacheShareSourceId = -1;
        Log.d(TAG, "subscribe result: subscribeId=" + subscribeId + " ret=" + ret);
        return ret;
    }

    public void clearImage(boolean black) {
        if (black) {
            clearImage(0.0F, 0.0F, 0.0F, 1.0F);
        } else {
            clearImage(0.0F, 0.0F, 0.0F, 0.0F);
        }
    }


    public long getSubscribeId() {
        return mSubscribeId;
    }


    public int getVideoType() {
        return mRawDataType.ordinal();
    }

    public boolean isSubscribeSuccess() {
        return isSubscribeSuccess;
    }

    public MobileRTCRawDataError unSubscribe() {
        if (!isSubscribeSuccess) {
            return MobileRTCRawDataError.MobileRTCRawData_Success;
        }
        MobileRTCRawDataError ret = rawDataHelper.unSubscribe();
        Log.d(Helper.TAG, "unSubscribe: ret=" + ret + ":" + "mSubscribeId=" + mSubscribeId);
        if (ret == MobileRTCRawDataError.MobileRTCRawData_Success) {
            mSubscribeId = -1;
            isSubscribeSuccess = false;
        }
        return ret;
    }

    public void release() {
        rawDataHelper = null;
    }
}

