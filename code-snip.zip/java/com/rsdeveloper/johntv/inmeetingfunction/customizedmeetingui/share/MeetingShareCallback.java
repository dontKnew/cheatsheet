package com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.share;

import us.zoom.sdk.InMeetingShareController;
import us.zoom.sdk.ShareSettingType;
import us.zoom.sdk.ZoomSDK;
import us.zoom.sdk.ZoomSDKSharingSourceInfo;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.BaseCallback;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.BaseEvent;

public class MeetingShareCallback extends BaseCallback<MeetingShareCallback.ShareEvent> {

    public interface ShareEvent extends BaseEvent {

        void onShareUserReceivingStatus(long userId);

        void onShareSettingTypeChanged(ShareSettingType type);

        void onSharingStatus(ZoomSDKSharingSourceInfo sharingSourceInfo);
    }

    static MeetingShareCallback instance;

    private MeetingShareCallback() {
        init();
    }


    protected void init() {
        ZoomSDK.getInstance().getInMeetingService().getInMeetingShareController().addListener(shareListener);
    }

    public static MeetingShareCallback getInstance() {
        if (null == instance) {
            synchronized (MeetingShareCallback.class) {
                if (null == instance) {
                    instance = new MeetingShareCallback();
                }
            }
        }
        return instance;
    }

    InMeetingShareController.InMeetingShareListener shareListener = new InMeetingShareController.InMeetingShareListener() {

        @Override
        public void onShareContentChanged(ZoomSDKSharingSourceInfo sharingSourceInfo) {
            
        }

        @Override
        public void onSharingStatus(ZoomSDKSharingSourceInfo sharingSourceInfo) {
            for (ShareEvent event : callbacks) {
                event.onSharingStatus(sharingSourceInfo);
            }
        }

        @Override
        public void onShareUserReceivingStatus(long userId) {

            for (ShareEvent event : callbacks) {
                event.onShareUserReceivingStatus(userId);
            }
        }

        @Override
        public void onShareSettingTypeChanged(ShareSettingType type) {
            for (ShareEvent event : callbacks) {
                event.onShareSettingTypeChanged(type);
            }
        }
    };

}
