package com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.remotecontrol;

import android.util.Log;

import us.zoom.sdk.InMeetingRemoteController;
import us.zoom.sdk.InMeetingService;
import us.zoom.sdk.ZoomSDK;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.view.share.CustomShareView;

public class MeetingRemoteControlHelper implements InMeetingRemoteController.InMeetingRemoteControlListener {

    private final static String TAG = MeetingRemoteControlHelper.class.getSimpleName();

    private InMeetingRemoteController mInMeetingRemoteController;

    private InMeetingService mInMeetingService;

    private CustomShareView customShareView;

    private long mShareSourceID;

    public void setShareSourceID(long mShareSourceID) {
        this.mShareSourceID = mShareSourceID;
        if (null != customShareView) {
            customShareView.setShareSourceID(mShareSourceID);
        }
    }

    public MeetingRemoteControlHelper(CustomShareView shareView) {
        this.customShareView = shareView;
        mInMeetingRemoteController = ZoomSDK.getInstance().getInMeetingService().getInMeetingRemoteController();
        mInMeetingRemoteController.addListener(this);
        mInMeetingService = ZoomSDK.getInstance().getInMeetingService();
        if (null != customShareView) {
            customShareView.setShareSourceID(mShareSourceID);
        }
    }

    public void refreshRemoteControlStatus() {
        boolean hasPrivilege = mInMeetingRemoteController.hasRemoteControlPrivilege(mShareSourceID);
        boolean isRc = mInMeetingRemoteController.isRemoteController(mShareSourceID);
        customShareView.enableRC(hasPrivilege, isRc);
    }

    public void onDestroy() {
        if (null != mInMeetingRemoteController) {
            mInMeetingRemoteController.removeListener(this);
        }
    }

    public boolean isEnableRemoteControl() {
        return customShareView.isRemoteControlActive();
    }


    @Override
    public void onUserGetRemoteControlPrivilege(long shareSourceID) {
        setShareSourceID(shareSourceID);
        boolean hasPriv = mInMeetingRemoteController.hasRemoteControlPrivilege(shareSourceID);
        boolean isRc = mInMeetingRemoteController.isRemoteController(shareSourceID);
        customShareView.enableRC(hasPriv, isRc);
        Log.d(TAG, "onUserGetRemoteControlPrivilege userId:" + shareSourceID + " hasPriv:" + hasPriv + " isRc:" + isRc);
    }

    @Override
    public void remoteControlStarted(long shourceId) {
        long myUserId = mInMeetingService.getMyUserID();

        boolean hasPriv = mInMeetingRemoteController.hasRemoteControlPrivilege(mShareSourceID);
        boolean isRc = mInMeetingRemoteController.isRemoteController(mShareSourceID);

        Log.d(TAG, "remoteControlStarted shourceId:" + shourceId + " myUserId:" + myUserId + " hasPriv:" + hasPriv + " isRc:" + isRc);
            if (isRc) {
                mInMeetingRemoteController.startRemoteControl(mShareSourceID);
            }
        customShareView.enableRC(hasPriv, isRc);
    }
}
