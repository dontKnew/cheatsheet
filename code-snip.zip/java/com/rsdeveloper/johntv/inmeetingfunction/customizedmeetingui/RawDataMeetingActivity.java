package com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import us.zoom.sdk.InMeetingAudioController;
import us.zoom.sdk.InMeetingEventHandler;
import us.zoom.sdk.InMeetingLiveStreamController;
import us.zoom.sdk.InMeetingShareController;
import us.zoom.sdk.InMeetingUserInfo;
import us.zoom.sdk.MeetingParameter;
import us.zoom.sdk.MeetingServiceListener;
import us.zoom.sdk.MeetingStatus;
import us.zoom.sdk.RawLiveStreamInfo;
import us.zoom.sdk.RequestRawLiveStreamPrivilegeHandler;
import us.zoom.sdk.ShareSettingType;
import us.zoom.sdk.SharingStatus;
import us.zoom.sdk.ZoomSDK;
import us.zoom.sdk.ZoomSDKRawDataType;
import us.zoom.sdk.ZoomSDKSharingSourceInfo;
import us.zoom.sdk.ZoomSDKVideoResolution;
import us.zoom.sdk.ZoomSDKVideoSourceHelper;
import com.rsdeveloper.johntv.R;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.audio.MeetingAudioHelper;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.rawdata.AudioRawDataUtil;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.rawdata.RawDataRender;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.rawdata.UserVideoAdapter;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.rawdata.VirtualVideoSource;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.video.MeetingVideoHelper;

public class RawDataMeetingActivity extends FragmentActivity implements MeetingServiceListener, InMeetingShareController.InMeetingShareListener,
        InMeetingLiveStreamController.InMeetingLiveStreamListener, View.OnClickListener, UserVideoAdapter.ItemTapListener {


    private final static String TAG = RawDataMeetingActivity.class.getSimpleName();

    public final static int REQUEST_PLIST = 1001;

    public final static int REQUEST_CAMERA_CODE = 1010;

    public final static int REQUEST_AUDIO_CODE = 1011;

    public final static int REQUEST_SHARE_SCREEN_PERMISSION = 1001;

    protected final static int REQUEST_SYSTEM_ALERT_WINDOW = 1002;

    RawDataRender bigVideo;

    View actionBarContainer;

    ImageView videoStatusImage;

    ImageView audioStatusImage;

    long myUserId;

    ZoomSDKSharingSourceInfo currentShareSource;

    private MeetingVideoHelper videoHelper;

    private MeetingAudioHelper audioHelper;

    private AudioRawDataUtil audioRawDataUtil;

    protected RecyclerView userVideoList;

    protected LinearLayout videoListContain;

    protected UserVideoAdapter adapter;

    private View switchToShare;

    VirtualVideoSource virtualVideoSource;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        setContentView(R.layout.activity_rawdata);
        bigVideo = findViewById(R.id.big_video);
        bigVideo.setOnClickListener(this);

        startPreview();

        videoHelper = new MeetingVideoHelper(this, videoCallBack);
        audioHelper = new MeetingAudioHelper(audioCallBack);

        actionBarContainer = findViewById(R.id.action_bar_container);
        videoStatusImage = findViewById(R.id.videotatusImage);

        audioStatusImage = findViewById(R.id.audioStatusImage);

        findViewById(R.id.btnCamera).setOnClickListener(this);
        findViewById(R.id.btnAudio).setOnClickListener(this);
        findViewById(R.id.btn_leave).setOnClickListener(this);
        findViewById(R.id.btnSwitchCamera).setOnClickListener(this);
        findViewById(R.id.btn_switch_source).setOnClickListener(this);

        switchToShare = findViewById(R.id.btn_switch_share);
        switchToShare.setOnClickListener(this);

        audioRawDataUtil = new AudioRawDataUtil(getApplicationContext());

        userVideoList = findViewById(R.id.userVideoList);
        videoListContain = findViewById(R.id.video_list_contain);
        adapter = new UserVideoAdapter(this, this);
        userVideoList.setItemViewCacheSize(0);
        userVideoList.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        userVideoList.setAdapter(adapter);
        setScrollListener();
        ZoomSDK.getInstance().getInMeetingService().addListener(inmeetingListener);
        ZoomSDK.getInstance().getMeetingService().addListener(this);
        ZoomSDK.getInstance().getInMeetingService().getInMeetingShareController().addListener(this);
        ZoomSDK.getInstance().getInMeetingService().getInMeetingLiveStreamController().addListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        bigVideo.unSubscribe();
        adapter.clear();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumeSubscribe();
    }

    private void resumeSubscribe() {
        long myUserId = ZoomSDK.getInstance().getInMeetingService().getMyUserID();
        if (null != currentShareSource) {
            subscribe(currentShareSource.getShareSourceID(), ZoomSDKRawDataType.RAW_DATA_TYPE_SHARE);
        } else {
            subscribe(myUserId, ZoomSDKRawDataType.RAW_DATA_TYPE_VIDEO);
        }
        adapter.clear();
        List<Long> userInfoList = ZoomSDK.getInstance().getInMeetingService().getInMeetingUserList();
        if (null != userInfoList && userInfoList.size() > 0) {
            adapter.onUserJoin(userInfoList);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        int displayRotation = display.getRotation();
        ZoomSDK.getInstance().getInMeetingService().getInMeetingVideoController().rotateMyVideo(displayRotation);
        if (null != actionBarContainer) {
            actionBarContainer.bringToFront();
        }
    }

    private void setScrollListener() {
        final int margin = 0;
        userVideoList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    LinearLayoutManager linearLayoutManager = (LinearLayoutManager) userVideoList.getLayoutManager();
                    View view = linearLayoutManager.getChildAt(0);
                    int index = linearLayoutManager.findFirstVisibleItemPosition();
                    int left = view.getLeft();
                    if (left < 0) {
                        if (-left > view.getWidth() / 2) {
                            index = index + 1;
                            if (index == adapter.getItemCount() - 1) {
                                recyclerView.scrollBy(view.getWidth(), 0);
                            } else {
                                recyclerView.scrollBy(view.getWidth() + left + 2 * margin, 0);
                            }
                        } else {
                            recyclerView.scrollBy(left - 2 * margin, 0);
                        }
                        if (index == 0) {
                            recyclerView.scrollTo(0, 0);
                        }
                    }
                }
            }
        });

    }

    private void startPreview() {
        if (!checkVideoPermission()) {
            return;
        }
        bigVideo.setRawDataResolution(ZoomSDKVideoResolution.VideoResolution_720P);
        bigVideo.subscribe(0, ZoomSDKRawDataType.RAW_DATA_TYPE_VIDEO);
        bigVideo.setVideoAspectModel(RawDataRender.VideoAspect_Full_Filled);
    }

    private void subscribe(long subscribeId, ZoomSDKRawDataType type) {
        bigVideo.unSubscribe();
        if (type == ZoomSDKRawDataType.RAW_DATA_TYPE_VIDEO) {
            if (subscribeId == ZoomSDK.getInstance().getInMeetingService().getMyUserID()) {
                bigVideo.setVideoAspectModel(RawDataRender.VideoAspect_Full_Filled);
            } else {
                bigVideo.setVideoAspectModel(RawDataRender.VideoAspect_PanAndScan);
            }
        } else {
            bigVideo.setVideoAspectModel(RawDataRender.VideoAspect_PanAndScan);
        }
        bigVideo.setRawDataResolution(ZoomSDKVideoResolution.VideoResolution_720P);
        bigVideo.subscribe(subscribeId, type);
    }

    private boolean checkVideoPermission() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_CODE);
            return false;
        }
        return true;
    }

    @Override
    public void onSingleTap(long subscribeId) {
        if (null != currentShareSource) {
            switchToShare.setVisibility(View.VISIBLE);
        } else {
            switchToShare.setVisibility(View.GONE);
        }
        subscribe(subscribeId, ZoomSDKRawDataType.RAW_DATA_TYPE_VIDEO);
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (viewId == R.id.btnCamera) {
            videoHelper.switchVideo();

        } else if (viewId == R.id.btnAudio) {
            audioHelper.switchAudio();

        } else if (viewId == R.id.big_video) {
            actionBarContainer.setVisibility(actionBarContainer.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            // changeResolution();

        } else if (viewId == R.id.btn_leave) {
            releaseResource();
            ZoomSDK.getInstance().getMeetingService().leaveCurrentMeeting(false);

        } else if (viewId == R.id.btn_switch_share) {
            if (null != currentShareSource) {
                switchToShare.setVisibility(View.GONE);
                subscribeShare();
            }
        } else if (viewId == R.id.btnSwitchCamera) {
            if (ZoomSDK.getInstance().getInMeetingService().getInMeetingVideoController().canSwitchCamera()) {
                ZoomSDK.getInstance().getInMeetingService().getInMeetingVideoController().switchToNextCamera();
            }

        } else if (viewId == R.id.btn_switch_source) {
            ZoomSDKVideoSourceHelper sourceHelper = ZoomSDK.getInstance().getVideoSourceHelper();
            if (v.getTag() == null || !((boolean) v.getTag())) {
                if (virtualVideoSource == null) {
                    virtualVideoSource = new VirtualVideoSource(RawDataMeetingActivity.this);
                }
                v.setTag(true);
                sourceHelper.setExternalVideoSource(virtualVideoSource);
            } else {
                v.setTag(false);
                sourceHelper.setExternalVideoSource(null);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (permissions == null || grantResults == null) {
            return;
        }

        for (int i = 0; i < permissions.length; i++) {
            if (Manifest.permission.CAMERA.equals(permissions[i])) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    startPreview();
                }
            }
        }
    }

    private void releaseResource() {
        bigVideo.unSubscribe();
        adapter.clear();
    }

    private void changeResolution() {
        int resolution = bigVideo.getResolution().ordinal();
        resolution++;
        if (resolution > ZoomSDKVideoResolution.VideoResolution_720P.ordinal()) {
            resolution = 0;
        }
        ZoomSDKVideoResolution videoResolution = ZoomSDKVideoResolution.fromValue(resolution);
        bigVideo.setRawDataResolution(videoResolution);
    }

//    @Override
//    public void onConfigurationChanged(Configuration newConfig) {
//        super.onConfigurationChanged(newConfig);
//        Display display = ((WindowManager) getSystemService(Service.WINDOW_SERVICE)).getDefaultDisplay();
//        int displayRotation = display.getRotation();
//        ZoomSDK.getInstance().getInMeetingService().getInMeetingVideoController().rotateMyVideo(displayRotation);
//        actionBarContainer.bringToFront();
//    }

    @Override
    public void onBackPressed() {
        ZoomSDK.getInstance().getMeetingService().leaveCurrentMeeting(false);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        audioRawDataUtil.unSubscribe();
        ZoomSDK.getInstance().getMeetingService().removeListener(this);
        ZoomSDK.getInstance().getInMeetingService().removeListener(inmeetingListener);
        ZoomSDK.getInstance().getInMeetingService().getInMeetingLiveStreamController().removeListener(this);
        ZoomSDK.getInstance().getInMeetingService().getInMeetingShareController().removeListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQUEST_SHARE_SCREEN_PERMISSION:
                if (resultCode != RESULT_OK) {
                    Log.d(TAG, "onActivityResult REQUEST_SHARE_SCREEN_PERMISSION no ok ");
                    break;
                }
//                startShareScreen(data);
                break;
            case REQUEST_SYSTEM_ALERT_WINDOW:
//                meetingShareHelper.startShareScreenSession(mScreenInfoData);
                break;
        }
    }

    MeetingAudioHelper.AudioCallBack audioCallBack = new MeetingAudioHelper.AudioCallBack() {
        @Override
        public boolean requestAudioPermission() {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(RawDataMeetingActivity.this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_CODE);
                return false;
            }
            return true;
        }

        @Override
        public void updateAudioButton() {
            RawDataMeetingActivity.this.updateAudioButton();
        }
    };

    public void updateAudioButton() {
        InMeetingAudioController audioController = ZoomSDK.getInstance().getInMeetingService().getInMeetingAudioController();
        if (audioController.isAudioConnected()) {
            if (audioController.isMyAudioMuted()) {
                audioStatusImage.setImageResource(R.drawable.icon_meeting_audio_disconnect);
            } else {
                audioStatusImage.setImageResource(R.drawable.icon_meeting_join_audio);
            }
        } else {
            audioStatusImage.setImageResource(R.drawable.icon_meeting_join_audio);
        }
    }

    MeetingVideoHelper.VideoCallBack videoCallBack = new MeetingVideoHelper.VideoCallBack() {
        @Override
        public boolean requestVideoPermission() {
            return true;
        }

        @Override
        public void showCameraList(PopupWindow popupWindow) {
        }
    };

    @Override
    public void onMeetingStatusChanged(MeetingStatus meetingStatus, int errorCode, int internalErrorCode) {
        if (meetingStatus == MeetingStatus.MEETING_STATUS_IN_WAITING_ROOM) {
            myUserId = 0;
            bigVideo.unSubscribe();
            Toast.makeText(this, "In waiting room", Toast.LENGTH_LONG).show();
        }
        if (meetingStatus == MeetingStatus.MEETING_STATUS_RECONNECTING) {
            audioRawDataUtil.unSubscribe();
            releaseResource();
            finish();
        }
        if (meetingStatus == MeetingStatus.MEETING_STATUS_INMEETING) {
            resumeSubscribe();
        }

    }

    Dialog builder;

    private void showPsswordDialog(final boolean needPassword, final boolean needDisplayName, final InMeetingEventHandler handler) {
        if (null != builder) {
            builder.dismiss();
        }
        builder = new Dialog(this, us.zoom.videomeetings.R.style.ZMDialog);
        builder.setTitle("Need password or displayName");
        builder.setContentView(R.layout.layout_input_password_name);

        final EditText pwd = builder.findViewById(R.id.edit_pwd);
        final EditText name = builder.findViewById(R.id.edit_name);
        builder.findViewById(R.id.layout_pwd).setVisibility(needPassword ? View.VISIBLE : View.GONE);
        builder.findViewById(R.id.layout_name).setVisibility(needDisplayName ? View.VISIBLE : View.GONE);

        builder.findViewById(R.id.btn_leave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                builder.dismiss();
                ZoomSDK.getInstance().getInMeetingService().leaveCurrentMeeting(true);
            }
        });
        builder.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = pwd.getText().toString();
                String userName = name.getText().toString();
                if (needPassword && TextUtils.isEmpty(password) || (needDisplayName && TextUtils.isEmpty(userName))) {
                    builder.dismiss();
                    inmeetingListener.onMeetingNeedPasswordOrDisplayName(needPassword, needDisplayName, handler);
                    return;
                }
                builder.dismiss();
                handler.setMeetingNamePassword(password, userName, false);
            }
        });
        builder.setCanceledOnTouchOutside(false);
        builder.setCancelable(false);
        builder.show();
        pwd.requestFocus();
    }


    private SimpleInMeetingListener inmeetingListener = new SimpleInMeetingListener() {


        @Override
        public void onMeetingNeedPasswordOrDisplayName(boolean needPassword, boolean needDisplayName, InMeetingEventHandler handler) {
            showPsswordDialog(needPassword, needDisplayName, handler);
        }

        @Override
        public void onMeetingFail(int errorCode, int internalErrorCode) {
            Toast.makeText(RawDataMeetingActivity.this, "onMeetingFail:" + errorCode, Toast.LENGTH_LONG).show();
        }


        @Override
        public void onMeetingLeaveComplete(long ret) {
            audioRawDataUtil.unSubscribe();
            releaseResource();
            finish();
        }

        @Override
        public void onMeetingUserJoin(List<Long> userList) {
            actionBarContainer.setVisibility(View.VISIBLE);

            adapter.onUserJoin(userList);
            if (adapter.getItemCount() > 0) {
                videoListContain.setVisibility(View.VISIBLE);
            }

            if (myUserId <= 0) {
                audioRawDataUtil.subscribeAudio();
                myUserId = ZoomSDK.getInstance().getInMeetingService().getMyUserID();
                findViewById(R.id.text_connecting).setVisibility(View.GONE);
            }
        }

        @Override
        public void onMeetingUserLeave(List<Long> userList) {
            adapter.onUserLeave(userList);
            if (adapter.getItemCount() == 0) {
                videoListContain.setVisibility(View.INVISIBLE);
            }
            if (userList.contains(bigVideo.getSubscribeId())) {
                long myUserId = ZoomSDK.getInstance().getInMeetingService().getMyUserID();
                if (myUserId != 0) {
                    subscribe(myUserId, ZoomSDKRawDataType.RAW_DATA_TYPE_VIDEO);
                } else {
                    bigVideo.unSubscribe();
                }
            }
        }

        @Override
        public void onUserAudioTypeChanged(long userId) {
            if (ZoomSDK.getInstance().getInMeetingService().isMyself(userId)) {
                updateAudioButton();
            }
        }

        @Override
        public void onUserAudioStatusChanged(long userId, AudioStatus audioStatus) {
            if (ZoomSDK.getInstance().getInMeetingService().isMyself(userId)) {
                updateAudioButton();
            }
        }


        @Override
        public void onUserVideoStatusChanged(long userId, VideoStatus status) {
            InMeetingUserInfo userInfo = ZoomSDK.getInstance().getInMeetingService().getUserInfoById(userId);
            if (null == userInfo) {
                return;
            }

            if (userId == myUserId) {
                if (status != VideoStatus.Video_ON) {
                    videoStatusImage.setImageResource(R.drawable.icon_meeting_video_mute);
                } else {
                    videoStatusImage.setImageResource(R.drawable.icon_meeting_video);
                }
            }
            if (userId == bigVideo.getSubscribeId()) {
                if (VideoStatus.Video_ON != status) {
                    bigVideo.onVideoStatusChange(false);
                }
            }

            adapter.onUserVideoStatusChanged(userId, status);
        }

    };

    private void subscribeShare() {
        if (null != currentShareSource) {
            switchToShare.setVisibility(View.GONE);
            if (currentShareSource.getShareSourceID() > 0) {
                subscribe(currentShareSource.getShareSourceID(), ZoomSDKRawDataType.RAW_DATA_TYPE_SHARE);
            } else {
                long bigVideoUserId = adapter.getSelectedVideoUserId();
                if (bigVideoUserId <= 0) {
                    bigVideoUserId = myUserId;
                }
                subscribe(bigVideoUserId, ZoomSDKRawDataType.RAW_DATA_TYPE_VIDEO);
            }
        }
    }

    @Override
    public void onShareUserReceivingStatus(long userId) {
    }
    @Override
    public void onShareSettingTypeChanged(ShareSettingType type) {
    }

    @Override
    public void onSharingStatus(ZoomSDKSharingSourceInfo sharingSourceInfo) {
        if (sharingSourceInfo.getStatus() == SharingStatus.Sharing_Other_Share_Begin) {
            currentShareSource = sharingSourceInfo;
            subscribeShare();
        } else {
            if (null != currentShareSource && currentShareSource.getShareSourceID() == sharingSourceInfo.getShareSourceID()) {
                if (sharingSourceInfo.getStatus() == SharingStatus.Sharing_Other_Share_End || sharingSourceInfo.getStatus() == SharingStatus.Sharing_Self_Send_End) {
                    currentShareSource = null;
                    switchToShare.setVisibility(View.GONE);
                    resumeSubscribe();
                }
            }
        }
    }

    @Override
    public void onMeetingParameterNotification(MeetingParameter meetingParameter) {
    }
    @Override
    public void onLiveStreamStatusChange(InMeetingLiveStreamController.MobileRTCLiveStreamStatus status) {
        if (status == InMeetingLiveStreamController.MobileRTCLiveStreamStatus.MobileRTCLiveStreamStatus_StartSucceed) {
            if (ZoomSDK.getInstance().getInMeetingService().isMeetingHost()) {
                //resubscribe
                bigVideo.unSubscribe();
                adapter.clear();
                resumeSubscribe();
            }
        }
    }

    @Override
    public void onRawLiveStreamPrivilegeChanged(boolean bHasPrivilege) {

    }

    @Override
    public void onUserRawLiveStreamPrivilegeChanged(long userId, boolean bHasPrivilege) {

    }

    @Override
    public void onRequestRawLiveStreamPrivilegeRequested(RequestRawLiveStreamPrivilegeHandler handler) {

    }

    @Override
    public void onUserRawLiveStreamingStatusChanged(List<RawLiveStreamInfo> livingList) {

        if (!ZoomSDK.getInstance().hasRawDataLicense()) {
            bigVideo.unSubscribe();
        }
        long myUserId = ZoomSDK.getInstance().getInMeetingService().getMyUserID();

        for (RawLiveStreamInfo info : livingList) {
            if (info.getUserId() == myUserId) {
                if (ZoomSDK.getInstance().hasRawDataLicense()) {
                    resumeSubscribe();
                }
                break;
            }
        }

    }

    @Override
    public void onRawLiveStreamPrivilegeRequestTimeout() {

    }



    @Override
    public void onShareContentChanged(ZoomSDKSharingSourceInfo sharingSourceInfo) {

    }

    @Override
    public void onLiveStreamReminderStatusChanged(boolean enable) {

    }

    @Override
    public void onLiveStreamReminderStatusChangeFailed() {

    }

    @Override
    public void onUserThresholdReachedForLiveStream(int percent) {

    }
}
