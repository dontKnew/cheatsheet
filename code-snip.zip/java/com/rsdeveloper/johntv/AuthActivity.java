package com.rsdeveloper.johntv;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import us.zoom.sdk.InMeetingService;
import us.zoom.sdk.ZoomSDK;

public class AuthActivity extends AppCompatActivity {
    protected SessionHelper session;
    protected NetworkHelper network;
    private  Context context;
    private ValueEventListener deviceIdListener;
    private DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        session = new SessionHelper(this);
        network = new NetworkHelper();
        if(!session.getBoolean("is_auth", false)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }

        int userId = session.getInt("user_id", 0);
        userRef = FirebaseDatabase.getInstance().getReference("users").child(String.valueOf(userId));

        deviceIdListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String registeredDeviceId = snapshot.getValue(String.class);
                String deviceId = Helper.getAndroidId(getApplicationContext());

                if (registeredDeviceId != null && !deviceId.equals(registeredDeviceId)) {
                    FirebaseAuth.getInstance().signOut();
                    Toast.makeText(getApplicationContext(), "Your account is logged in on another device", Toast.LENGTH_LONG).show();

                    if (ZoomSDK.getInstance().isInitialized()) {
                        InMeetingService mInMeetingService = ZoomSDK.getInstance().getInMeetingService();
                        if (mInMeetingService != null) {
                            mInMeetingService.leaveCurrentMeeting(false);
                        } else {
                            Log.e("Zoom", "InMeetingService is null");
                        }
                    } else {
                        Log.e("Zoom", "Zoom SDK not initialized");
                    }

                    directLogout();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("AuthActivity", "Database error: " + error.getMessage());
                Helper.alertBox(getApplicationContext(), "Database error: " + error.getMessage());
                directLogout();
            }
        };
        userRef.child("deviceId").addValueEventListener(deviceIdListener);


    }

    protected void alertBox(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Close", (dialog, which) -> dialog.dismiss())
                .show();
    }

    public void logout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Are you sure you want to logout?")
                .setCancelable(false)
                .setPositiveButton("Yes", (dialog, which) -> directLogout())
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .show();
    }


    protected void directLogout() {
        if(userRef != null && deviceIdListener != null) {
            userRef.child("deviceId").removeEventListener(deviceIdListener);
        }
        String username = session.getString("username", "User");
        String password = session.getString("password", "");

        session.clear();
        session.saveBoolean("is_auth", false);
        session.saveString("username", username);
        session.saveString("password", password);

        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public void home(View v) {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    public void changePassword(View v) {
        startActivity(new Intent(this, ChangePasswordActivity.class));
        finish();
    }
    private void handleAuthResponse(String result) {
        try {
            JSONObject response = new JSONObject(result);
            boolean success = response.getBoolean("success");
            if (!success) {
                String statusCode = response.optString("status_code", "unknown");
                String message = response.optString("message", "Unknown error occurred");
                if("user_not_found".equals(statusCode) || "multi_device_login".equals(statusCode) || "user_inactive".equals(statusCode)) {
                    directLogout();
                    //alertBox("Error", message);
                } else {
                    alertBox("Error", message);
                }
            }
        } catch (JSONException e) {
            alertBox("Error", "Failed to parse response: " + e.getMessage());
        }
    }

}
