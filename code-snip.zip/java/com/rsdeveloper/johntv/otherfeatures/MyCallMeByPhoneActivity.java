package com.rsdeveloper.johntv.otherfeatures;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import us.zoom.sdk.MeetingService;
import us.zoom.sdk.PhoneHelper;
import us.zoom.sdk.PhoneHelperListener;
import us.zoom.sdk.ZoomSDK;
import com.rsdeveloper.johntv.R;

public class MyCallMeByPhoneActivity extends Activity implements View.OnClickListener, PhoneHelperListener {
	private static final String TAG = MyCallMeByPhoneActivity.class.getSimpleName();
	private Button mBtnCall;
	private Button mBtnHangup;
	private EditText mEdtPhoneNumber;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.call_me_activity);
		
		mEdtPhoneNumber = (EditText)findViewById(R.id.edtPhoneNumber);
		mBtnCall = (Button)findViewById(R.id.btnCall);
		mBtnCall.setOnClickListener(this);
		mBtnHangup = (Button)findViewById(R.id.btnHangUp);
		mBtnHangup.setOnClickListener(this);
		
		initButtons();
		
		ZoomSDK zoomSDK = ZoomSDK.getInstance();
		MeetingService meetingService = zoomSDK.getMeetingService();
		if(meetingService != null) {
			PhoneHelper phoneHelper = meetingService.getPhoneHelper();
			if(phoneHelper != null){
				phoneHelper.addListener(this);
			}
		}
	}
	
	@Override
	public void onClick(View arg0) {
		ZoomSDK zoomSDK = ZoomSDK.getInstance();
		MeetingService meetingService = zoomSDK.getMeetingService();
		if(meetingService == null){
			return;
		}
		PhoneHelper phoneHelper = meetingService.getPhoneHelper();
		if(phoneHelper == null){
			return;
		}
		if(arg0.getId() == R.id.btnCall) {

			String number = mEdtPhoneNumber.getText().toString().trim();
			List<PhoneHelper.PhoneSupportCountryInfo> supportCountryInfo = phoneHelper.getSupportCountryInfo();
			if (supportCountryInfo != null) {
				PhoneHelper.PhoneSupportCountryInfo phoneSupportCountryInfo = supportCountryInfo.get(0);
				if (phoneSupportCountryInfo != null) {
					phoneHelper.inviteCallOutUser(phoneSupportCountryInfo.getCountryCode(), number, null);
				}
			}
		} else if(arg0.getId() == R.id.btnHangUp) {
			phoneHelper.cancelCallOutUser();
		}
	}
		
	private void initButtons() {
		ZoomSDK zoomSDK = ZoomSDK.getInstance();
		MeetingService meetingService = zoomSDK.getMeetingService();
		if (meetingService == null) {
			return;
		}
		PhoneHelper phoneHelper = meetingService.getPhoneHelper();
		if (phoneHelper == null) {
			return;
		}
		if (phoneHelper.getInviteCallOutUserStatus() == PhoneHelper.PhoneStatus.PhoneStatus_Calling) {
			mBtnCall.setEnabled(false);
			mBtnHangup.setEnabled(true);
		} else {
			mBtnCall.setEnabled(true);
			mBtnHangup.setEnabled(false);
		}
	}
	
	private void updateButtons(PhoneHelper.PhoneStatus status) {
		switch(status) {
			case PhoneStatus_None:
			case PhoneStatus_Failed:
			case PhoneStatus_Canceled:
				mBtnCall.setEnabled(true);
				mBtnHangup.setEnabled(false);
				break;
			case PhoneStatus_Calling:
			case PhoneStatus_Ringing:
			case PhoneStatus_Accepted:
			case PhoneStatus_Success:
				mBtnCall.setEnabled(false);
				mBtnHangup.setEnabled(true);
				break;
			case PhoneStatus_Canceling:
				mBtnCall.setEnabled(false);
				mBtnHangup.setEnabled(false);
				break;
		}
	}
	
	@Override
	protected void onDestroy() {
		ZoomSDK zoomSDK = ZoomSDK.getInstance();
		
		if(zoomSDK.isInitialized()) {
			MeetingService meetingService = zoomSDK.getMeetingService();
			if (meetingService != null) {
				PhoneHelper phoneHelper = meetingService.getPhoneHelper();
				if (phoneHelper != null) {
					phoneHelper.removeListener(this);
				}
			}
		}
		
		super.onDestroy();
	}

	@Override
	public void onInviteCallOutUserStatus(PhoneHelper.PhoneStatus status, PhoneHelper.PhoneFailedReason reason) {
		Log.d(TAG, "onInviteCallOutUserStatus status = " + status);
		if(status == PhoneHelper.PhoneStatus.PhoneStatus_Success) {
			finish();
		}
		updateButtons(status);
	}

	@Override
	public void onCallMeStatus(PhoneHelper.PhoneStatus status, PhoneHelper.PhoneFailedReason reason) {

	}
}
