package com.rsdeveloper.johntv;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.provider.Settings;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Helper {
    public static  Boolean HIDE_USER_IF_VIDEO_OFF = true;
    public static  Boolean SHOW_USERNAME_FROM_VIDEO_LIST = true;
    public static Boolean enableHD = true;
    public static Boolean HIDE_VIDEO_LIST_ON_VIDEO_TOGGLE = false;
    public static String TAG = "Kritika";
    public static  String BASE_URL = "https://johntv.live";
    public static  String API_URL = Helper.BASE_URL+"/api";

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            Network network = connectivityManager.getActiveNetwork();
            if (network != null) {
                NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(network);
                return networkCapabilities != null && (
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                                networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                                networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                );
            }
        }
        return false;
    }

    @SuppressLint("HardwareIds")
    public static String getAndroidId(Context context) {
        String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
          return androidId;
    }

    public static String currentDateTime() {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm:a");
        Date currentDate = new Date();
        return dateFormat.format(currentDate);
    }

    public static String currentDateTime(int minutesToAdd) {
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm a");
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, minutesToAdd);
        return dateFormat.format(calendar.getTime());
    }

    public static long currentTimestamp(int minutesToAdd) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, minutesToAdd);
        return calendar.getTimeInMillis();
    }

    public static long currentTimestamp() {
        Calendar calendar = Calendar.getInstance();
        return calendar.getTimeInMillis();
    }


    public static void alertBox(Context context, String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setTitle(title != null ? title : "Alert")
                .setCancelable(false)
                .setPositiveButton("Close", (dialog, which) -> dialog.dismiss());

        if (message != null && !message.trim().isEmpty()) {
            builder.setMessage(message);
        }

        builder.show();
    }

    public static void alertBox(Context context, String title) {
        new AlertDialog.Builder(context)
                .setTitle(title != null ? title : "Alert")
                .setCancelable(false)
                .setPositiveButton("Close", (dialog, which) -> dialog.dismiss())
                .show();
    }



}
