package com.rsdeveloper.johntv;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import org.json.JSONException;
import org.json.JSONObject;

public class ChangePasswordActivity extends AuthActivity {

    TextView alert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_activity_changepassword);
        alert = findViewById(R.id.alert);
    }

    @SuppressLint("SetTextI18n")
    public void updateUserPassword(View v) {
        EditText oldPassword = findViewById(R.id.oldpass);
        EditText newPassword = findViewById(R.id.newpass);
        EditText confirmPassword = findViewById(R.id.cpass);
        Button updateButton = findViewById(R.id.changePassword);

        String oldPwd = oldPassword.getText().toString().trim();
        String newPwd = newPassword.getText().toString().trim();
        String confirmPwd = confirmPassword.getText().toString().trim();
        alert.setVisibility(View.GONE);
        if (newPwd.isEmpty() || confirmPwd.isEmpty()) {
            alert.setVisibility(View.VISIBLE);
            alert.setText("Password cannot be blank");
            return;
        }

        if (!newPwd.equals(confirmPwd)) {
            alert.setVisibility(View.VISIBLE);
            alert.setText("Passwords do not match");
            return;
        }

        if (newPwd.length() < 6) {
            alert.setVisibility(View.VISIBLE);
            alert.setText("Password should be at least 6 characters long");
            return;
        }

        updateButton.setEnabled(false);
        updateButton.setText("Please wait...");
        try {
            SessionHelper session = new SessionHelper(this);
            JSONObject data = new JSONObject();
            data.put("old_password", oldPwd);
            data.put("new_password", newPwd);
            data.put("user_id", session.getInt("user_id", 0));
            this.network.makePostRequest(Helper.API_URL + "/change-password", data, new NetworkHelper.PostRequestCallback() {
                @Override
                public void onSuccess(String result) {
                    runOnUiThread(() -> {
                        try {
                            updateButton.setEnabled(true);
                            updateButton.setText("Change Password");
                            JSONObject response = new JSONObject(result);
                            if(response.getBoolean("success")) {
                                alert.setVisibility(View.VISIBLE);
                                alert.setText(response.getString("message"));
                                alert.setTextColor(getResources().getColor(R.color.green));
                                oldPassword.setText("");
                                newPassword.setText("");
                                confirmPassword.setText("");
                            } else {
                                alert.setVisibility(View.VISIBLE);
                                alert.setText(response.getString("message"));
                            }
                        } catch (JSONException e) {
                            alert.setVisibility(View.VISIBLE);
                            alert.setText("Error: " + e.getMessage());
                        }
                    });
                }

                @SuppressLint("SetTextI18n")
                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        alert.setVisibility(View.VISIBLE);
                        alert.setText("Error: " + error);
                        updateButton.setEnabled(true);
                        updateButton.setText("Change Password");
                    });
                }
            });
        } catch (Exception e) {
            alert.setVisibility(View.VISIBLE);
            alert.setText("Error: " + e.getMessage());
            updateButton.setEnabled(true);
            updateButton.setText("Change Password");
        }

    }


}
