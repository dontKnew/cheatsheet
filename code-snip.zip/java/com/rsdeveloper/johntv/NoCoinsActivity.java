package com.rsdeveloper.johntv;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class NoCoinsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_activity_nocoins);
        // get putExtra data
        /*Intent intent = getIntent();
            String data = intent.getStringExtra("coins_data_line");
            TextView coins_data = findViewById(R.id.coins_data);
            coins_data.setText(data);
         */
    }

}