package com.rsdeveloper.johntv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import us.zoom.sdk.InMeetingNotificationHandle;
import us.zoom.sdk.JoinMeetingParams;
import us.zoom.sdk.MeetingParameter;
import us.zoom.sdk.MeetingService;
import us.zoom.sdk.MeetingServiceListener;
import us.zoom.sdk.MeetingStatus;
import us.zoom.sdk.SimpleZoomUIDelegate;
import us.zoom.sdk.ZoomError;
import us.zoom.sdk.ZoomSDK;
import us.zoom.sdk.ZoomSDKInitParams;
import us.zoom.sdk.ZoomSDKInitializeListener;

import com.rsdeveloper.johntv.initsdk.AuthConstants;
import com.rsdeveloper.johntv.initsdk.InitAuthSDKHelper;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.MyMeetingActivity;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.view.MeetingWindowHelper;
import com.rsdeveloper.johntv.inmeetingfunction.zoommeetingui.CustomNewZoomUIActivity;
import com.rsdeveloper.johntv.inmeetingfunction.zoommeetingui.ZoomMeetingUISettingHelper;
import com.rsdeveloper.johntv.models.MeetingModel;

import org.json.JSONException;
import org.json.JSONObject;

public class StartMeetingActivity extends AuthActivity implements MeetingServiceListener {

    private  static String TAG ;

    public static boolean showMeetingTokenUI = false;

    private MeetingModel meeting;
    private ZoomSDK mZoomSDK;
    public String sdktoken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mZoomSDK = ZoomSDK.getInstance();
//        setContentView(R.layout.a_activity_startmeeting);
         meeting = (MeetingModel) getIntent().getSerializableExtra("meetingModel");
//        meeting = new MeetingModel("89963662901", "Testing Meeting", "2023-08-07");
        TAG = Helper.TAG;
        setSDK();
    }

    InMeetingNotificationHandle handle = (context, intent) -> {
        intent = new Intent(context, MyMeetingActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        if (!(context instanceof Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        intent.setAction(InMeetingNotificationHandle.ACTION_RETURN_TO_CONF);
        context.startActivity(intent);
        return true;
    };

    @Override
    public void onBackPressed() {
        if (null == ZoomSDK.getInstance().getMeetingService()) {
            super.onBackPressed();
            return;
        }
        MeetingStatus meetingStatus = ZoomSDK.getInstance().getMeetingService().getMeetingStatus();
        if (meetingStatus == MeetingStatus.MEETING_STATUS_INMEETING) {
            moveTaskToBack(true);
        } else {
            super.onBackPressed();
        }
    }

    public void joinMeeting(Context context, MeetingModel meeting) {
        String username = this.session.getString("name", "Unknown User");
        if (!ZoomSDK.getInstance().isInitialized()) {
            Helper.alertBox(context, "SDK Not Initialized", "Something wrong, try again!");
            return;
        }
        MeetingService meetingService = ZoomSDK.getInstance().getMeetingService();
        if (meetingService == null) {
            Helper.alertBox(context, "Service Error", "MeetingService is null, unable to join the meeting.");
            return;
        }
        try {
            this.network.makeGetRequest(Helper.API_URL + "/meeting/" + meeting.getMeetingId(), new NetworkHelper.GetRequestCallback() {
                @Override
                public void onSuccess(String result) {
                    runOnUiThread(() -> {
                        JSONObject response;
                        try {
                            response = new JSONObject(result);
                            if (response.getBoolean("success")) {
                                JSONObject jsondata = response.getJSONObject("data");
                                String zoomMeetingId = jsondata.getString("zoom_meeting_id");
                                String meetingPassword = jsondata.getString("meeting_password");

                                ZoomSDK.getInstance().getMeetingSettingsHelper().setCustomizedMeetingUIEnabled(true);
                                ZoomSDK.getInstance().getSmsService().enableZoomAuthRealNameMeetingUIShown(false);

                                JoinMeetingParams params = new JoinMeetingParams();
                                params.displayName = username;
                                params.meetingNo = zoomMeetingId;
                                params.password = meetingPassword;
                                int result1 = meetingService.joinMeetingWithParams(context, params, ZoomMeetingUISettingHelper.getJoinMeetingOptions());
                                if (result1 != ZoomError.ZOOM_ERROR_SUCCESS) {
                                    Helper.alertBox(context, "Join Meeting Failed", "Error joining meeting & Server Response: " + response.getString("message"));
                                }
                            } else {
                                Helper.alertBox(context, "Join Meeting Failed", response.getString("message"));
                            }
                        } catch (JSONException e) {
                            Helper.alertBox(context, "Join Meeting Failed", e.toString());
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        Helper.alertBox(context, "Join Meeting Failed - 152", error);
                    });
                }
            });
        } catch (Exception e) {
            Helper.alertBox(this, "Join Meeting Failed - 151", "Error: " + e.toString());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setMiniWindows();
    }

    private void setMiniWindows() {
        if (null != mZoomSDK && mZoomSDK.isInitialized() && !mZoomSDK.getMeetingSettingsHelper().isCustomizedMeetingUIEnabled()) {
            ZoomSDK.getInstance().getZoomUIService().setZoomUIDelegate(new SimpleZoomUIDelegate() {
                @Override
                public void afterMeetingMinimized(Activity activity) {
                    Intent intent = new Intent(activity, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    activity.startActivity(intent);
                }
            });
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onMeetingParameterNotification(MeetingParameter meetingParameter) {
        Log.d(Helper.TAG, "onMeetingParameterNotification " + meetingParameter);
    }

    @Override
    public void onMeetingStatusChanged(MeetingStatus meetingStatus, int errorCode, int internalErrorCode) {
        if (!ZoomSDK.getInstance().isInitialized()) {
            Helper.alertBox(getApplicationContext(), "SDK Not Initialized", "Something wrong, try again!");
            return;
        }
        Intent intent = new Intent(this, MyMeetingActivity.class);
        intent.putExtra("from", MyMeetingActivity.JOIN_FROM_UNLOGIN);
        intent.putExtra("meeting_topic", meeting.getMeetingTitle());
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        this.startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        MeetingWindowHelper.getInstance().onActivityResult(requestCode, this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (null != ZoomSDK.getInstance().getMeetingService()) {
            ZoomSDK.getInstance().getMeetingService().removeListener(this);
        }
        if (null != ZoomSDK.getInstance().getMeetingSettingsHelper()) {
            ZoomSDK.getInstance().getMeetingSettingsHelper().setCustomizedNotificationData(null, null);
        }
        InitAuthSDKHelper.getInstance().reset();
    }

    public void setSDK() {
        try {
            network.makeGetRequest(Helper.API_URL + "/meeting/sdk-token", new NetworkHelper.GetRequestCallback() {
                @Override
                public void onSuccess(String result) {
                    runOnUiThread(() -> {
                        JSONObject response;
                        try {
                            response = new JSONObject(result);
                            if (response.getBoolean("success")) {
                                ZoomSDKInitParams initParams = new ZoomSDKInitParams();
                                sdktoken = response.getString("data");
                                initializeSdk(getApplicationContext());
                            } else {
                                Helper.alertBox(getApplicationContext(), "Token Fetch Failed-135", response.getString("message"));
                            }
                        } catch (JSONException e) {
                            Helper.alertBox(getApplicationContext(), "Token Fetch Failed-139", e.toString());
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    Helper.alertBox(getApplicationContext(), "Token Fetch Failed-146", error);
                }
            });
        } catch (Exception e) {
            Helper.alertBox(getApplicationContext(), "Token Fetch Failed - 151", "Error : " + e.toString());
        }
    }

    public void initializeSdk(Context context) {
        ZoomSDK sdk = ZoomSDK.getInstance();
        ZoomSDKInitParams initParams = new ZoomSDKInitParams();
        initParams.jwtToken = this.sdktoken;
        initParams.enableLog = true;
        initParams.enableGenerateDump = true;
        initParams.logSize = 5;
        initParams.domain = AuthConstants.WEB_DOMAIN;
        Log.d(Helper.TAG, "cALLED init");
        ZoomSDKInitializeListener listener = new ZoomSDKInitializeListener() {
            @Override
            public void onZoomSDKInitializeResult(int errorCode, int internalErrorCode) {
                ZoomSDK.getInstance().getZoomUIService().setNewMeetingUI(CustomNewZoomUIActivity.class);
                ZoomSDK.getInstance().getZoomUIService().disablePIPMode(false);
                ZoomSDK.getInstance().getMeetingSettingsHelper().enable720p(Helper.enableHD);
                ZoomSDK.getInstance().getMeetingSettingsHelper().enableShowMyMeetingElapseTime(true);
                ZoomSDK.getInstance().getMeetingService().addListener(StartMeetingActivity.this); // add listener to this activity
                ZoomSDK.getInstance().getMeetingSettingsHelper().setCustomizedNotificationData(null, handle);
                Log.d(Helper.TAG, "Init Success");
                joinMeeting(context, meeting);
            }
            @Override
            public void onZoomAuthIdentityExpired() {
                Helper.alertBox(context, "SDK Not Initialized - 270", "Something wrong, try again!");
            }
        };

        sdk.initialize(context, listener, initParams);
    }

    public void  goBack(View view){
        Intent intent = new Intent(this, MainActivity.class);
        this.startActivity(intent);
        finish();
    }
}
