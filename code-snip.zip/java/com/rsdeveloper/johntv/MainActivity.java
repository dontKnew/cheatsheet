package com.rsdeveloper.johntv;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.rsdeveloper.johntv.adapters.MeetingCardAdapter;
import com.rsdeveloper.johntv.initsdk.AuthConstants;
import com.rsdeveloper.johntv.initsdk.InitAuthSDKHelper;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.MyMeetingActivity;
import com.rsdeveloper.johntv.inmeetingfunction.customizedmeetingui.view.MeetingWindowHelper;
import com.rsdeveloper.johntv.inmeetingfunction.zoommeetingui.CustomNewZoomUIActivity;
import com.rsdeveloper.johntv.inmeetingfunction.zoommeetingui.ZoomMeetingUISettingHelper;
import com.rsdeveloper.johntv.models.MeetingModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import us.zoom.sdk.InMeetingNotificationHandle;
import us.zoom.sdk.InMeetingService;
import us.zoom.sdk.JoinMeetingParams;
import us.zoom.sdk.MeetingOptions;
import us.zoom.sdk.MeetingParameter;
import us.zoom.sdk.MeetingService;
import us.zoom.sdk.MeetingServiceListener;
import us.zoom.sdk.MeetingStatus;
import us.zoom.sdk.SimpleZoomUIDelegate;
import us.zoom.sdk.ZoomError;
import us.zoom.sdk.ZoomSDK;
import us.zoom.sdk.ZoomSDKInitParams;
import us.zoom.sdk.ZoomSDKInitializeListener;


public class MainActivity extends AuthActivity implements MeetingServiceListener {

    private MeetingModel currentMeeting;
    private ZoomSDK sdk;
    public String sdktoken;
    RecyclerView recyclerView;
    MeetingCardAdapter adapter;
    private ProgressBar loaderSpinner;
    ArrayList<MeetingModel> dataList = new ArrayList<>();
    private ImageView noDataBanner;
    private SwipeRefreshLayout swipeRefreshLayout;
    private Context context;
    private InMeetingService mInMeetingService;
    private AlertDialog dialog;
    private String zoomMeetingId;
    private String zoomMeetingPass;
    private  boolean isResumed = false;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_activity_main);

        TextView welcomeText = findViewById(R.id.welcome_text);
        welcomeText.setText(this.session.getString("username", "Unknown"));
        noDataBanner = findViewById(R.id.NoDataBanner);
        FrameLayout logoutButton = findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(v-> this.logout());

        recyclerView = findViewById(R.id.meetingCardRecycler);
        loaderSpinner = findViewById(R.id.loader_spinner);
        swipeRefreshLayout = findViewById(R.id.swipeRefresh);

        int start = 0;
        int end = (int) TypedValue.applyDimension( TypedValue.COMPLEX_UNIT_DIP, 100, getResources().getDisplayMetrics());
        swipeRefreshLayout.setProgressViewOffset(false, start, end);

        showLoader();
        loadMeetingList();

        context = this;
        sdk = ZoomSDK.getInstance();
//        Log.d(Helper.TAG, "SDK Version " + sdk.getVersion(this));
        hasAppUpdate();
    }

    private void loadMeetingList(){
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new MeetingCardAdapter(this, dataList);
        recyclerView.setAdapter(adapter);
        setMeetingData(this);
        swipeRefreshLayout.setOnRefreshListener(() -> {
            setMeetingData(this);
        });
    }

    private void showLoader() {
        loaderSpinner.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
    }

    private void hideLoader() {
        loaderSpinner.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
    }
    @SuppressLint("SetTextI18n")
    public void afterZoomSDK(){
        sdk.getMeetingService().addListener(this);
        mInMeetingService = sdk.getInMeetingService();
        if (mInMeetingService.isMeetingConnected()) {
            Log.d(Helper.TAG, "Meeting Disconnected...");
            mInMeetingService.leaveCurrentMeeting(false);
        }
        joinMeetingConfig();
    }

    public void setMeetingData(Context context) {
        try {

            SessionHelper session = new SessionHelper(this);
            this.network.makeGetRequest(Helper.API_URL + "/meeting/list?user_id="+session.getInt("user_id", 0), new NetworkHelper.GetRequestCallback() {
                @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
                @Override
                public void onSuccess(String result) {
                    runOnUiThread(() -> {
                        try {
                            swipeRefreshLayout.postDelayed(() -> {

                                swipeRefreshLayout.setRefreshing(false);
                            }, 2000);
                            JSONObject response = new JSONObject(result);
                            if (response.getBoolean("success")) {
                                JSONArray dataArray = response.getJSONArray("data");
                                TextView coins_data = findViewById(R.id.coins_data);
                                coins_data.setText(response.getString("balance_coins")+" Days left");
                                coins_data.setVisibility(View.VISIBLE);
                                MainActivity.this.dataList.clear();
                                for(int i = 0; i < dataArray.length(); i++) {
                                    JSONObject meeting = dataArray.getJSONObject(i);
                                    String meetingId = meeting.getString("zoom_meeting_id");
                                    String meetingName = meeting.getString("meeting_name");
                                    String createdAt = meeting.getString("created_at");
                                    MainActivity.this.dataList.add(new MeetingModel(meetingId, meetingName, createdAt));
                                }
                                hideLoader();
                                adapter.notifyDataSetChanged();
                            } else {
                                hideLoaderShowBanner();
                                if(response.getString("error_code").equals("coins_expired")){
                                    directLogout();
                                }else{
                                    Helper.alertBox(context, "Meetings List Failed-169", response.getString("message"));
                                }
                            }
                        } catch (JSONException e) {
                            hideLoaderShowBanner();
                            swipeRefreshLayout.postDelayed(() -> {
                                swipeRefreshLayout.setRefreshing(false);
                            }, 2000);
                            Helper.alertBox(context, "Meeting List Failed-173", e.getMessage());
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        hideLoaderShowBanner();
                        swipeRefreshLayout.postDelayed(() -> {
                            swipeRefreshLayout.setRefreshing(false);
                        }, 2000);
                        Helper.alertBox(context, "Meeting Fetch Failed-169", error);
                    });
                }
            });
        } catch (Exception e) {
            hideLoaderShowBanner();
            swipeRefreshLayout.postDelayed(() -> {
                swipeRefreshLayout.setRefreshing(false);
            }, 2000);
            this.alertBox("Meeting Fetch Failed - 183", "Error: " + e.getMessage());
        }
    }

    public void startMeeting(MeetingModel meeting) {
        currentMeeting = meeting;
        requestJoinMeeting(this, meeting);
    }

    public void setSDK() {
        try {
            network.makeGetRequest(Helper.API_URL + "/meeting/sdk-token", new NetworkHelper.GetRequestCallback() {
                @Override
                public void onSuccess(String result) {
                    runOnUiThread(() -> {
                        JSONObject response;
                        try {
                            response = new JSONObject(result);
                            if (response.getBoolean("success")) {
                                sdktoken = response.getString("data");
                                Log.d(Helper.TAG, "SDK Token Get "+sdktoken);
                                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                                    initializeSdk(context);
                                }, 500);
                            } else {
                                hideLoaderShowBanner();
                                Helper.alertBox(context, "Token Fetch Failed-135", response.getString("message"));
                            }
                        } catch (JSONException e) {
                            hideLoaderShowBanner();
                            Helper.alertBox(context, "Token Fetch Failed-139", e.toString());
                        }
                    });
                }
                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        hideLoaderShowBanner();
                        Helper.alertBox(context, "Token Fetch Failed-146", error);
                    });
                }
            });
        } catch (Exception e) {
            runOnUiThread(() -> {
                hideLoaderShowBanner();
                Helper.alertBox(context, "Token Fetch Failed - 151", "Error : " + e.toString());
            });
        }
    }

    public void initializeSdk(Context context) {
        if(sdk!=null){
            ZoomSDKInitParams initParams = new ZoomSDKInitParams();
            initParams.jwtToken = this.sdktoken;
            initParams.enableLog = false;
            initParams.enableGenerateDump = false;
            initParams.logSize = 5;
            initParams.domain = "zoom.us";
            ZoomSDKInitializeListener listener = new ZoomSDKInitializeListener() {
                @Override
                public void onZoomSDKInitializeResult(int errorCode, int internalErrorCode) {
                    if (errorCode != ZoomError.ZOOM_ERROR_SUCCESS) {
                        Toast.makeText(context, "Failed to initialize Zoom SDK. Error: " + errorCode + ", internalErrorCode=" + internalErrorCode, Toast.LENGTH_LONG).show();
                    }else {
//                        sdk.getZoomUIService().setNewMeetingUI(CustomNewZoomUIActivity.class);
                        sdk.getZoomUIService().disablePIPMode(true); // disalbe the picture in picture flaoting meeting
                        sdk.getMeetingSettingsHelper().enable720p(Helper.enableHD);
                        sdk.getMeetingSettingsHelper().enableShowMyMeetingElapseTime(true);
//                        sdk.getMeetingSettingsHelper().enable5GHighBandWidth(true); // // remove internal bandwidth limit for higher quality:contentReference[oaicite:11]{index=11}
                        sdk.getMeetingSettingsHelper().setCustomizedNotificationData(null, handle);
                        Log.d(Helper.TAG, "is 720p "+ sdk.getMeetingSettingsHelper().is720PEnabled());
                        afterZoomSDK();
                    }

                }
                @Override
                public void onZoomAuthIdentityExpired() {
                    Helper.alertBox(context, "Zoom Auth Identity Expired - 259", "Something wrong, try again!");
                }
            };
            sdk.initialize(context, listener, initParams);
        }else {
            Toast.makeText(context, "SDK Not Setup, Please try again later", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onMeetingParameterNotification(MeetingParameter meetingParameter) {
        //Log.d(Helper.TAG, "onMeetingParameterNotification " + meetingParameter);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onMeetingStatusChanged(MeetingStatus meetingStatus, int errorCode, int internalErrorCode) {
        if (!sdk.isInitialized()) {
            Helper.alertBox(context, "Meeting Not Initialized", "Please close app properly and reopen...");
            return;
        }else {
            if (meetingStatus == MeetingStatus.MEETING_STATUS_CONNECTING) {
                if (ZoomMeetingUISettingHelper.useExternalVideoSource) {
                    ZoomMeetingUISettingHelper.changeVideoSource(true, MainActivity.this);
                }
            }
            if(meetingStatus==MeetingStatus.MEETING_STATUS_INMEETING){
                MeetingWindowHelper.getInstance().showMeetingWindow(this);
                adapter.notifyDataSetChanged();
                Log.d(Helper.TAG, "Meeting User Info"+ mInMeetingService.getInMeetingUserList().toString());
            }else{
                MeetingWindowHelper.getInstance().hiddenMeetingWindow(true);
            }
        }
    }
    private void redirectUserIfInMeeting(){
        InMeetingService inMeetingService = ZoomSDK.getInstance().getInMeetingService();
        if(inMeetingService != null && inMeetingService.isMeetingConnected()) {
            joinMeeting();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        MeetingWindowHelper.getInstance().onActivityResult(requestCode, this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (null != sdk.getMeetingService()) {
            sdk.getMeetingService().removeListener(this);
        }
        if (null != sdk.getMeetingSettingsHelper()) {
            sdk.getMeetingSettingsHelper().setCustomizedNotificationData(null, null);
        }
        InitAuthSDKHelper.getInstance().reset();
    }

    InMeetingNotificationHandle handle = (context, intent) -> {
        intent = new Intent(context, MyMeetingActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        if (!(context instanceof Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        intent.setAction(InMeetingNotificationHandle.ACTION_RETURN_TO_CONF);
        context.startActivity(intent);
        return true;
    };

    public void requestJoinMeeting(Context context, MeetingModel meeting) {
        MeetingService meetingService = sdk.getMeetingService();
        if(meetingService != null) {
            meetingService.leaveCurrentMeeting(false);  // if leave any meeting if already joined
        }
        zoomMeetingId = null;
        zoomMeetingPass = null;
        sdktoken = null;
        try {
            this.network.makeGetRequest(Helper.API_URL + "/meeting/" + meeting.getMeetingId(), new NetworkHelper.GetRequestCallback() {
                @Override
                public void onSuccess(String result) {
                    runOnUiThread(() -> {
                        JSONObject response;
                        try {
                            response = new JSONObject(result);
                            if (response.getBoolean("success")) {
                                JSONObject jsondata = response.getJSONObject("data");
                                zoomMeetingId = jsondata.getString("zoom_meeting_id");
                                zoomMeetingPass = jsondata.getString("meeting_password");
                                sdktoken = response.getString("sdk_token");
                                initializeSdk(context);
                            } else {
                                if(response.get("status_code")=="user_not_found"){
                                    directLogout();
                                    //Helper.alertBox(context, "Your account probably be deleted, contact service provider");
                                }else if(response.get("status_code")=="user_inactive"){
                                    directLogout();
                                    //Helper.alertBox(context, "Your account disabled, contact service provider");
                                }else{
                                    directLogout();
                                    //Helper.alertBox(context, "Join Meeting Failed", response.getString("message"));
                                }
                            }
                        } catch (JSONException e) {
                            Helper.alertBox(context, "Join Meeting Failed", e.toString());
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        Helper.alertBox(context, "Join Meeting Failed - 152", error);
                    });
                }
            });
        } catch (Exception e) {
            Helper.alertBox(this, "Join Meeting Failed - 151", "Error: " + e.toString());
        }
    }

    private void joinMeetingConfig(){
        MeetingService meetingService = sdk.getMeetingService();
        if(meetingService==null){
            Helper.alertBox(context, "Meeting Service", "Error Meeting Service is NULL: ");
            return ;
        }
        sdk.getMeetingSettingsHelper().setCustomizedMeetingUIEnabled(true);
        sdk.getSmsService().enableZoomAuthRealNameMeetingUIShown(false);
        String username = this.session.getString("name", "Unknown User");
        JoinMeetingParams params = new JoinMeetingParams();
        params.displayName = username;
        params.meetingNo = zoomMeetingId;
        params.password = zoomMeetingPass;
        int result1 = meetingService.joinMeetingWithParams(context, params, ZoomMeetingUISettingHelper.getJoinMeetingOptions());
        if (result1 != ZoomError.ZOOM_ERROR_SUCCESS) {
            Helper.alertBox(context, "Join Meeting Failed - 406", "Error joining meeting on Result1");
            return ;
        }else{
            joinMeeting();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!Helper.isNetworkAvailable(this)) {
            Intent intent = new Intent(this, NoInternetActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
            return;
        }
    }

    public void hideLoaderShowBanner(){
        noDataBanner.setVisibility(View.VISIBLE);
        hideLoader();
    }

    public void cancelMeeting(Context context, String title) {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
        LinearLayout layout = getLinearLayout(context, title);
        dialog = new MaterialAlertDialogBuilder(context)
                .setTitle(null)
                .setView(layout)
                .setCancelable(false)
                .create();
        dialog.show();
    }

    @SuppressLint({"SetTextI18n", "NotifyDataSetChanged"})
    private @NonNull LinearLayout getLinearLayout(Context context, String title) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 20);

        int primary = ContextCompat.getColor(context, R.color.primary);
        TextView titleView = new TextView(context);
        titleView.setText(title != null ? title : "Information");
        titleView.setTextSize(18);
        titleView.setTextColor(primary);
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setPadding(0, 20, 0, 0);
        titleView.setGravity(Gravity.CENTER);

        // Create a ProgressBar (spinner) with a custom color
        ProgressBar progressBar = new ProgressBar(context);
        progressBar.setIndeterminate(true);
        progressBar.setIndeterminateTintList(ColorStateList.valueOf(Color.RED));

        Button backButton = new MaterialButton(context);
        backButton.setText("Back");
        int white = ContextCompat.getColor(context, R.color.white);
        int primary1 = ContextCompat.getColor(context, R.color.primary1);
        backButton.setTextColor(primary);
        backButton.setBackgroundColor(primary1);
        backButton.setPadding(10, 10, 10 , 10);
        backButton.setOnClickListener(view -> {
            mInMeetingService.leaveCurrentMeeting(false);
            adapter.notifyDataSetChanged();
            dialog.dismiss();
        });

        LinearLayout buttonLayout = new LinearLayout(context);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);
        buttonLayout.setPadding(0, 20, 0, 0);
        buttonLayout.addView(backButton);

        layout.addView(progressBar);
        layout.addView(titleView);
        layout.addView(buttonLayout);

        return layout;
    }
    private void joinMeeting(){
        Intent intent = new Intent(context, MyMeetingActivity.class);
        intent.putExtra("from", MyMeetingActivity.JOIN_FROM_UNLOGIN);
        intent.putExtra("meeting_topic", currentMeeting.getMeetingTitle());
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }


    public void hasAppUpdate() {
        NetworkHelper networkHelper = new NetworkHelper();
        networkHelper.makeGetRequest(Helper.API_URL + "/settings/appVersion", new NetworkHelper.GetRequestCallback() {
            @Override
            public void onSuccess(String result) {
                runOnUiThread(() -> {
                    try {
                        JSONObject response = new JSONObject(result);
                        if (response.getBoolean("success")) {
                            String appVersion = response.getString("data"); // e.g., "0.4"
                            PackageManager pm = getApplicationContext().getPackageManager();
                            PackageInfo packageInfo = pm.getPackageInfo(getApplicationContext().getPackageName(), 0);
                            String currentAppVersion = packageInfo.versionName; // e.g., "0.3"

                            // Compare version strings
                            if (!appVersion.equals(currentAppVersion)) {
                                showUpdateDialog(
                                        "App Update Required",
                                        "A new version of the app is available. Please update to continue.",
                                        "Update",
                                        "https://play.google.com/store/apps/details?id=com.rsdeveloper.johntv"
                                );
                            } else {
//                                Helper.alertBox(context, "App is up to date.");
                            }
                        } else {
                            Helper.alertBox(context, "Error: " + result);
                        }
                    } catch (JSONException e) {
                        Helper.alertBox(context, "JSON Error: " + e.toString());
                    } catch (PackageManager.NameNotFoundException e) {
                        Helper.alertBox(context, "Package Error: " + e.toString());
                    }
                });
            }
            @Override
            public void onFailure(String error) {
                runOnUiThread(() -> {
                    Helper.alertBox(context, "Error: " + error);
                });
            }
        });
    }

    @Override
    public void onResume(){
        super.onResume();
        hasAppUpdate();
    }

    private void showUpdateDialog(String title, String message, String buttonText, String apkUrl) {
        new android.app.AlertDialog.Builder(this)
                .setTitle(title != null ? title : "Update Required")
                .setMessage(message != null ? message : "A new version of the app is available. Please update to continue.")
                .setCancelable(false)
                .setPositiveButton(buttonText != null ? buttonText : "Update", (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl));
                    startActivity(intent);
                })
                .setNegativeButton("Exit", (dialog, which) -> {
                    finish();
                    System.exit(0);
                }).show();
    }

}