package com.rsdeveloper.johntv.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rsdeveloper.johntv.MainActivity;
import com.rsdeveloper.johntv.R;
import com.rsdeveloper.johntv.models.MeetingModel;

import java.util.ArrayList;

public class MeetingCardAdapter extends RecyclerView.Adapter<MeetingCardAdapter.ViewHolder> {
    Context context;
    ArrayList<MeetingModel> dataList;

    public MeetingCardAdapter(Context context, ArrayList<MeetingModel> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    // 1st call
    @Override
    public int getItemCount() {
        return dataList.size();
    }

    // 2nd call
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.a_meeting_card, parent, false);
        return new ViewHolder(v);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {


        Button joinMeeting;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            joinMeeting = itemView.findViewById(R.id.joinMeeting);
        }
    }

    // 3rd cal
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        MeetingModel card = dataList.get(position);
        holder.joinMeeting.setText(card.getMeetingTitle());
        holder.joinMeeting.setOnClickListener(v -> {
            holder.joinMeeting.setText("Please Wait...");
            ((MainActivity) context).startMeeting(card);
        });
    }

}
