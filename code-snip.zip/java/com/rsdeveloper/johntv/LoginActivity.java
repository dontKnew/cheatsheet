package com.rsdeveloper.johntv;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    private SessionHelper session;
    private TextView alert;
    private Button loginButton;
    private Context context;
    private static final int UPDATE_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_activity_login);
        context = this;
        session = new SessionHelper(this);
        alert = findViewById(R.id.alert);
        SessionHelper session = new SessionHelper(this);
        if(session.getBoolean("is_auth", false)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }else {
            hasAppUpdate();
        }
        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password);
        if(!session.getBoolean("is_auth", true)){
            username.setText(session.getString("username", ""));
            password.setText(session.getString("password", ""));
        }
        loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(this::loginAccount);

        //Set App Version Name...
        PackageManager pm = getApplicationContext().getPackageManager();
        PackageInfo packageInfo = null;
        try {
            packageInfo = pm.getPackageInfo(getApplicationContext().getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            throw new RuntimeException(e);
        }
        String currentAppVersion = packageInfo.versionName; // e.g., "0.3"
        TextView version_name = findViewById(R.id.versionName);
        version_name.setText("App Version "+  currentAppVersion);
    }


    @SuppressLint("SetTextI18n")
    private void loginAccount(View v) {
        alert.setVisibility(View.GONE);
        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password);
        JSONObject jsonData = new JSONObject();
        try {
            jsonData.put("username", username.getText().toString());
            jsonData.put("password", password.getText().toString());
            jsonData.put("android_id", Helper.getAndroidId(this));
            jsonData.put("mobile_name", Build.BRAND);
            jsonData.put("mobile_model", Build.MODEL);
        } catch (JSONException e) {
            runOnUiThread(() -> {
                alert.setVisibility(View.VISIBLE);
                alert.setText("Error: " + e.toString());
            });
            return;
        }
        loginButton.setText("Please Wait");
        NetworkHelper networkHelper = new NetworkHelper();
        networkHelper.makePostRequest(Helper.API_URL + "/login", jsonData, new NetworkHelper.PostRequestCallback() {
            @Override
            public void onSuccess(String result) {
                runOnUiThread(() -> {
                    try {
                        JSONObject response = new JSONObject(result);
                        if(response.getBoolean("success")) {
                            signFirebase();
                            JSONObject jsonuser = response.getJSONObject("user");
                            alert.setVisibility(View.VISIBLE);
                            alert.setText("Login Success..");
                            session.saveBoolean("is_auth", true);
                            session.saveInt("user_id", jsonuser.getInt("id"));
                            session.saveString("username", jsonuser.getString("username"));
                            session.saveString("password", password.getText().toString());
                            session.saveString("name", jsonuser.getString("name"));
                            session.saveString("image", jsonuser.getString("image"));
                            session.saveString("created_at", jsonuser.getString("created_at"));
                            loginButton.setText("Login");
                        } else {
                            alert.setVisibility(View.VISIBLE);
                            alert.setText("Error: " + response.getString("message"));
                            loginButton.setText("Login");
                        }
                    } catch (JSONException e) {
                        alert.setVisibility(View.VISIBLE);
                        alert.setText("Error: " + e.toString());
                        loginButton.setText("Login");
                    }
                });
            }

            @Override
            public void onFailure(String error) {
                runOnUiThread(() -> {
                    alert.setVisibility(View.VISIBLE);
                    alert.setText("Error: " + error);
                    loginButton.setText("Login");
                });
            }
        });
    }

    public void viewPassword(View view) {
        EditText password = findViewById(R.id.password);
        ImageView icon = findViewById(R.id.eyeIcon);
        if (password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())) {
            password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            icon.setImageResource(R.drawable.a_eye);
        } else {
            password.setTransformationMethod(PasswordTransformationMethod.getInstance());
            icon.setImageResource(R.drawable.ic_hide_eye);
        }
        icon.invalidate();
        password.setSelection(password.getText().length());
    }

    public void signFirebase(){
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.signInAnonymously()
        .addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if(user != null) {
                    int panel_user_id = session.getInt("user_id", 0);
                    String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    String deviceId = Helper.getAndroidId(this);

                    DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(String.valueOf(panel_user_id));
                    Map<String, Object> userData = new HashMap<>();
                    userData.put("deviceId", deviceId);
                    userData.put("uid", userId);
                    userData.put("panel_user_id", panel_user_id);

                    userRef.updateChildren(userData)
                            .addOnSuccessListener(aVoid -> {
                                Log.d("Firebase", "Data saved successfully");
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                finish();
                            })
                            .addOnFailureListener(e -> {
                                Log.e("Firebase", "Failed to save data", e);
                                Toast.makeText(this, "Failed to save data", Toast.LENGTH_SHORT).show();
                                directLogout();
                            });
                }else{
                    Log.d(Helper.TAG, "Firebase sign-in failed: User is null");
                    Toast.makeText(this, "Firebase sign-in failed: User is null", Toast.LENGTH_SHORT).show();
                    directLogout();
                }
            } else {
                Log.d(Helper.TAG, "Firebase sign-in failed: " + Objects.requireNonNull(task.getException()).getMessage());
                Toast.makeText(this, "Firebase sign-in failed: " + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                directLogout();
            }
        });
    }

    protected void directLogout() {
        String username = session.getString("username", "User");
        String password = session.getString("password", "");

        session.clear();
        session.saveBoolean("is_auth", false);
        session.saveString("username", username);
        session.saveString("password", password);

        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


    private void showUpdateDialog(String title, String message, String buttonText, String apkUrl) {
        new AlertDialog.Builder(this)
                .setTitle(title != null ? title : "Update Required")
                .setMessage(message != null ? message : "A new version of the app is available. Please update to continue.")
                .setCancelable(false)
                .setPositiveButton(buttonText != null ? buttonText : "Update", (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl));
                    startActivity(intent);
                })
                .setNegativeButton("Exit", (dialog, which) -> {
                    finish();
                    System.exit(0);
                }).show();
    }


    public void hasAppUpdate() {
        NetworkHelper networkHelper = new NetworkHelper();
        networkHelper.makeGetRequest(Helper.API_URL + "/settings/appVersion", new NetworkHelper.GetRequestCallback() {
            @Override
            public void onSuccess(String result) {
                runOnUiThread(() -> {
                    try {
                        JSONObject response = new JSONObject(result);
                        if (response.getBoolean("success")) {
                            String appVersion = response.getString("data"); // e.g., "0.4"
                            PackageManager pm = getApplicationContext().getPackageManager();
                            PackageInfo packageInfo = pm.getPackageInfo(getApplicationContext().getPackageName(), 0);
                            String currentAppVersion = packageInfo.versionName; // e.g., "0.3"

                            // Compare version strings
                            if (!appVersion.equals(currentAppVersion)) {
                                showUpdateDialog(
                                        "App Update Required",
                                        "A new version of the app is available. Please update to continue.",
                                        "Update",
                                        "https://play.google.com/store/apps/details?id=com.rsdeveloper.johntv"
                                );
                            } else {
//                                Helper.alertBox(context, "App is up to date.");
                            }
                        } else {
                            Helper.alertBox(context, "Error: " + result);
                        }
                    } catch (JSONException e) {
                        Helper.alertBox(context, "JSON Error: " + e.toString());
                    } catch (PackageManager.NameNotFoundException e) {
                        Helper.alertBox(context, "Package Error: " + e.toString());
                    }
                });
            }
            @Override
            public void onFailure(String error) {
                runOnUiThread(() -> {
                    Helper.alertBox(context, "Error: " + error);
                });
            }
        });
    }

    @Override
    public void onResume(){
        super.onResume();
        hasAppUpdate();
    }
}
