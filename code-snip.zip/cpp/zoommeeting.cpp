// Write C++ code here.
//
// Do not forget to dynamically load the C++ library into your application.
//
// For instance,
//
// In MainActivity.java:
//    static {
//       System.loadLibrary("zoommeeting");
//    }
//
// Or, in MainActivity.kt:
//    companion object {
//      init {
//         System.loadLibrary("zoommeeting")
//      }
//    }


//Native NDK 29
// aarch64-linux-android → for arm64-v8a
//
//        arm-linux-androideabi → for armeabi-v7a
//
//        i686-linux-android → for x86
//
//        x86_64-linux-android → for x86_64